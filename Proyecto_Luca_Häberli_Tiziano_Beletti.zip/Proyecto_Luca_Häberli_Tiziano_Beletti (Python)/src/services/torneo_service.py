from src.database.connection import get_connection  # Importa la función para abrir la conexión a MySQL desde connection.py
from src.repositories.partido_repository import registrar_partido  # Importa la función encargada de insertar el partido en la base de datos


def programar_partido(id_partido, id_torneo, numero_fecha, id_equipo_local, id_equipo_visitante, dia, id_turno, nombre_cancha, id_complejo, estado):
    conexion = get_connection()  # Abre la conexión física con la base de datos MySQL
    cursor = conexion.cursor(dictionary=True)  # Crea un cursor configurado para que devuelva los registros como diccionarios (clave-valor)

    if id_equipo_local == id_equipo_visitante:  # Comprueba si el equipo local y el visitante son el mismo
        cursor.close()  # Cierra el cursor para liberar recursos
        conexion.close()  # Cierra la conexión a la BD para liberar recursos
        raise ValueError("Un equipo no puede jugar contra sí mismo.")  # Detiene la ejecución y lanza un error

    query = "SELECT id_torneo FROM equipo WHERE id_equipo = %s;"  # Consulta SQL para averiguar a qué torneo pertenece el equipo local
    valores = (id_equipo_local,)
    cursor.execute(query, valores)
    eq_local = cursor.fetchone()  # Guarda el resultado obtenido de la consulta del equipo local

    query = "SELECT id_torneo FROM equipo WHERE id_equipo = %s;"  # Consulta SQL para averiguar a qué torneo pertenece el equipo visitante
    valores = (id_equipo_visitante,)
    cursor.execute(query, valores)
    eq_visita = cursor.fetchone()  # Guarda el resultado obtenido de la consulta del equipo visitante

    if not eq_local or not eq_visita:  # Comprueba si ambos equipos existen realmente en la base de datos
        cursor.close()  # Cierra el cursor por seguridad
        conexion.close()  # Cierra la conexión por seguridad
        raise ValueError("Uno de los equipos especificados no existe.")  # Lanza error si algún equipo no fue encontrado

    if eq_local['id_torneo'] != id_torneo or eq_visita['id_torneo'] != id_torneo:  # Comprueba si ambos equipos están inscriptos en el mismo torneo que se intenta programar
        cursor.close()  # Cierra el cursor para ahorrar recursos
        conexion.close()  # Cierra la conexión para ahorrar recursos
        raise ValueError("Ambos equipos deben pertenecer a la misma edición del torneo.")  # Lanza error si pertenecen a torneos distintos

    query = "SELECT COUNT(*) AS total FROM equipo_jugador_torneo WHERE id_equipo = %s AND id_torneo = %s;"  # Consulta SQL que cuenta cuántos jugadores tiene el equipo local inscriptos en este torneo
    valores = (id_equipo_local, id_torneo)
    cursor.execute(query, valores)
    resultado = cursor.fetchone()
    count_local = resultado['total']  # Extrae el número total de jugadores del equipo local

    query = "SELECT COUNT(*) AS total FROM equipo_jugador_torneo WHERE id_equipo = %s AND id_torneo = %s;"  # Consulta SQL que cuenta cuántos jugadores tiene el equipo visitante inscriptos en este torneo
    valores = (id_equipo_visitante, id_torneo)
    cursor.execute(query, valores)
    resultado = cursor.fetchone()
    count_visita = resultado['total']  # Extrae el número total de jugadores del equipo visitante

    if count_local < 5 or count_visita < 5:  # Comprueba si alguno de los dos equipos tiene menos de 5 jugadores
        cursor.close()  # Cierra el cursor
        conexion.close()  # Cierra la conexión
        raise ValueError("Ambos equipos deben tener al menos 5 jugadores en su plantel para disputar el partido.")  # Lanza error si no se cumple el mínimo de jugadores

    query = """
        SELECT * FROM partido 
        WHERE id_torneo = %s AND estado != 'cancelado' AND ((id_equipo_local = %s AND id_equipo_visitante = %s) OR (id_equipo_local = %s AND id_equipo_visitante = %s));
    """  # Consulta SQL para buscar si estos dos equipos ya se enfrentaron antes en el torneo (en cualquier orden de local/visitante)
    valores = (id_torneo, id_equipo_local, id_equipo_visitante, id_equipo_visitante, id_equipo_local)
    cursor.execute(query, valores)  # Ejecuta la consulta del enfrentamiento previo
    if cursor.fetchone():  # Si la consulta devuelve algún registro, significa que ya jugaron entre sí
        cursor.close()  # Cierra el cursor para ahorrar recursos
        conexion.close()  # Cierra la conexión para ahorrar recursos
        raise ValueError("Los equipos ya tienen un partido registrado entre sí en esta edición del torneo.")  # Lanza error por enfrentamiento repetido

    query = """
        SELECT * FROM partido 
        WHERE id_torneo = %s AND numero_fecha = %s AND estado != 'cancelado' AND (id_equipo_local = %s OR id_equipo_visitante = %s OR id_equipo_local = %s OR id_equipo_visitante = %s);
    """  # Consulta SQL para verificar si cualquiera de los dos equipos ya tiene un partido asignado en la misma fecha del torneo
    valores = (id_torneo, numero_fecha, id_equipo_local, id_equipo_local, id_equipo_visitante, id_equipo_visitante)
    cursor.execute(query, valores)  # Ejecuta la consulta de control de fecha
    if cursor.fetchone():  # Si encuentra registros, significa que un equipo juega dos veces en la misma fecha
        cursor.close()  # Cierra el cursor para ahorrar recursos
        conexion.close()  # Cierra la conexión  para ahorrar recursos
        raise ValueError("Uno de los equipos ya tiene un partido programado en esta misma fecha del torneo.")  # Lanza error por superposición de partidos en la fecha

    query = """
        SELECT * FROM partido 
        WHERE id_torneo = %s AND dia = %s AND id_turno = %s AND nombre_cancha = %s AND id_complejo = %s AND estado != 'cancelado';
    """  # Consulta SQL para chequear si la misma cancha, complejo, día y turno ya están ocupados por otro partido
    # NOTA DE SEGURIDAD: Quitamos las comillas simples de '%s' en 'dia' y 'nombre_cancha'. El conector se encarga de ponerlas automáticamente.
    valores = (id_torneo, dia, id_turno, nombre_cancha, id_complejo)
    cursor.execute(query, valores)  # Ejecuta la consulta de disponibilidad de cancha
    if cursor.fetchone():  # Validación 6: Si encuentra un registro, la cancha ya está reservada en ese horario
        cursor.close()  # Cierra el cursor
        conexion.close()  # Cierra la conexión
        raise ValueError(
            "La cancha seleccionada ya tiene un partido asignado en ese mismo día y turno.")  # Lanza error por colisión de horarios en cancha

    cursor.close()  # Cierra el cursor de las consultas de validación una vez que todo salió bien
    conexion.close()  # Cierra la conexión temporalmente antes de pasar a guardar los datos

    exito = registrar_partido(id_partido, id_torneo, numero_fecha, id_equipo_local, id_equipo_visitante, dia, id_turno, nombre_cancha, id_complejo, estado)  # Llama a la función del repositorio para realizar el INSERT del partido en la base de datos y guarda el resultado (True/False)

    if not exito:  # Controla si el repositorio falló al intentar guardar el registro
        raise RuntimeError("No se pudo registrar el partido en la base de datos.")  # Lanza un error si la inserción en MySQL falló
    print("¡Partido programado con éxito!")
    return True  # Retorna True indicando que el partido fue validado y programado con éxito
