from src.database.connection import get_connection  # Importa la función para abrir la conexión a MySQL desde connection.py
from src.repositories.equipo_repository import fichar_jugador, quitar_jugador, cambiar_capitan  # Importa la función encargada de insertar el partido en la base de datos



def aniadir_jugador(id_equipo, ci_jugador, id_torneo, numero_camiseta):
    conexion = get_connection()  # Llamo a la función de connection.py para abrir la conexión a MySQL
    cursor = conexion.cursor(dictionary=True)  # dictionary=True devuelve los resultados como diccionarios (clave-valor)

    query = f"SELECT estado FROM torneo WHERE id_torneo= %s";
    valores = (id_torneo,)
    cursor.execute(query, valores)
    resultado = cursor.fetchone()
    if (resultado and resultado['estado'] == 'inscripción'):

        query = "SELECT COUNT(*) as total FROM equipo_jugador_torneo WHERE ci_jugador = %s AND id_torneo = %s"
        valores = (ci_jugador, id_torneo)
        cursor.execute(query, valores)
        resultado = cursor.fetchone()
        if resultado and resultado['total'] == 0:
            query = """
            SELECT e.id_facultad AS fac_equipo, j.id_facultad AS fac_jugador
            FROM equipo e
            INNER JOIN jugador j ON j.ci = %s
            WHERE e.id_equipo = %s 
            """
            valores = (ci_jugador, id_equipo)
            cursor.execute(query, valores)
            resultado = cursor.fetchone()
            if resultado and resultado['fac_equipo'] == resultado['fac_jugador']:
                query = "SELECT COUNT(*) as total FROM equipo_jugador_torneo WHERE id_equipo = %s AND id_torneo = %s"
                valores = (id_equipo, id_torneo)
                cursor.execute(query, valores)
                resultado = cursor.fetchone()
                if resultado and resultado['total'] < 10:
                    query = """
                    SELECT COUNT(*) as total
                    FROM jugador j
                    INNER JOIN equipo_jugador_torneo e ON e.ci_jugador = j.ci
                    WHERE e.id_equipo = %s
                    AND e.id_torneo = %s
                    AND j.tipo != 'grado' and j.tipo != 'posgrado'
                    """
                    valores = (id_equipo, id_torneo)
                    cursor.execute(query, valores)
                    resultado = cursor.fetchone()

                    if resultado and resultado['total'] < 2:

                        query = "SELECT COUNT(*) as total FROM equipo_jugador_torneo WHERE id_equipo = %s AND id_torneo = %s AND numero_camiseta = %s"
                        valores = (id_equipo, id_torneo, numero_camiseta)
                        cursor.execute(query, valores)
                        resultado = cursor.fetchone()
                        if resultado and resultado['total'] == 0:
                            resultado = fichar_jugador(id_equipo, ci_jugador, id_torneo, numero_camiseta)
                            cursor.close()  # Cierro el cursor para liberar memoria
                            conexion.close()  # Cierro la conexión para liberar memoria
                            return resultado
    cursor.close()  # Cierro el cursor para liberar memoria
    conexion.close()  # Cierro la conexión para liberar memoria
    return "No se pudo fichar al jugador"

def retirar_jugador(id_equipo, ci_jugador, id_torneo):
    conexion = get_connection()  # Llamo a la función de connection.py para abrir la conexión a MySQL
    cursor = conexion.cursor(dictionary=True)  # dictionary=True devuelve los resultados como diccionarios (clave-valor)

    query = f"SELECT estado FROM torneo WHERE id_torneo= %s";
    valores = (id_torneo,)
    cursor.execute(query, valores)
    resultado = cursor.fetchone()
    if (resultado and resultado['estado'] == 'inscripción'):

        query = "SELECT COUNT(*) as total FROM equipo_jugador_torneo WHERE id_equipo = %s AND id_torneo = %s"
        valores = (id_equipo, id_torneo)
        cursor.execute(query, valores)
        resultado = cursor.fetchone()

        if resultado and resultado['total'] > 5:
            quitar_jugador(id_equipo, ci_jugador, id_torneo)
            cursor.close()  # Cierro el cursor para liberar memoria
            conexion.close()  # Cierro la conexión para liberar memoria
            return "JUGADOR QUITADO CORRECTAMENTE"
        else:
            cursor.close()  # Cierro el cursor para liberar memoria
            conexion.close()  # Cierro la conexión para liberar memoria
            return "El equipo queda sin jugadores posibles (5 a 10)"
    else:
        cursor.close()  # Cierro el cursor para liberar memoria
        conexion.close()  # Cierro la conexión para liberar memoria
        return "No se encuentra en periodo de inscripcion"

def cambiar_lider (id_equipo,ci_jugador,id_torneo):
    conexion = get_connection()  # Llamo a la función de connection.py para abrir la conexión a MySQL
    cursor = conexion.cursor(dictionary=True)  # dictionary=True devuelve los resultados como diccionarios (clave-valor)

    query = "SELECT COUNT(*) as total FROM equipo_jugador_torneo WHERE id_equipo = %s AND ci_jugador = %s AND id_torneo = %s"
    valores = (id_equipo, ci_jugador, id_torneo)
    cursor.execute(query, valores)
    resultado = cursor.fetchone()

    if resultado and resultado['total'] > 0:
        cambiar_capitan(id_equipo,ci_jugador)
        cursor.close()
        conexion.close()
        return "CAPITAN CAMBIADO CORRECTAMENTE"
    else:
        cursor.close()
        conexion.close()
        return "No se pudo cambiar de capitan"