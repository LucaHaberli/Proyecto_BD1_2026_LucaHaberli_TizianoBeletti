from services.torneo_service import programar_partido  # Importa la función del servicio para programar partidos aplicando todas las reglas de negocio
from services.equipo_service import aniadir_jugador,retirar_jugador,cambiar_lider
from repositories.partido_repository import registrar_tarjeta, registrar_sancion, registrar_gol, registrar_en_planilla, \
    modificar_estado_partido, modificar_sancion, eliminar_partido, eliminar_sancion, corregir_gol_partido
from repositories.jugador_repository import registrar_jugador, modificar_jugador, eliminar_jugador
from repositories.equipo_repository import modificar_nombre_equipo, registrar_cancha, registrar_complejo, \
    obtener_todos_los_equipos, registrar_equipo, modificar_cancha, modificar_complejo, eliminar_equipo, \
    eliminar_complejo, eliminar_cancha
from repositories.reporte_repository import obtener_tabla_posiciones, obtener_goleadores, \
    obtener_tabla_fair_play, \
    obtener_promedio_goles_por_fecha, \
    obtener_promedio_goles_total, \
    obtener_canchas_mas_jugadas, \
    obtener_turnos_mas_jugados, \
    obtener_jugadores_por_facultad_y_tipo, \
    obtener_jugadores_sin_planilla, \
    obtener_partidos_jugados, \
    obtener_canchas_sinteticas, \
    obtener_porcentaje_partidos_estado, \
    obtener_todos_los_partidos_por_id, \
    obtener_sanciones_por_equipo_y_motivo  # Importa las funciones del repositorio de reportes para consultar posiciones y goleadores
from src.database.connection import iniciar_sesion


def main():  # Función principal que controla el ciclo de ejecución del programa
    print("--- BIENVENIDO AL SISTEMA DEL TORNEO UCU ---")

    rol_usuario = 'administrador' # Poner None para iniciar sesion
    usuario = 'admin_torneo' # Poner None para iniciar sesion
    contrasenia = 'PasswordAdmin123*' # Poner None para iniciar sesion
    while not rol_usuario:
        print("\n--- INICIO DE SESIÓN ---")
        usuario= input("Ingrese su usuario: ")
        correo = input("Correo electrónico: ")
        contrasenia = input("Contraseña: ")

        rol_usuario = iniciar_sesion(correo, contrasenia)

        if not rol_usuario:
            print("❌ Credenciales incorrectas. Intente de nuevo.")
        else:

            print(f"\n✅ Sesión iniciada como: {rol_usuario.upper()}")

    while True:
        print("\n--- TORNEO FÚTBOL 5 UCU ---")
        print("1. Registro")  # Opción para ir al menu de registro
        print("2. Modificacion")
        print("3. Eliminacion")
        print("4. Consultas")
        print("0. Salir")# Opción para cerrar la aplicación

        opcion = input("Seleccione una opción: ")
        match opcion:
            case "1":
                while True:
                    print("\n--- Registro ---")
                    print("--- Registro Equipo ---")
                    print("1. Registrar Equipo")
                    print("2. Registrar Jugador")
                    print("3. Fichar Jugador")
                    print("4. Quitar Jugador")
                    print("5. Cambiar Capitan")
                    print("--- Complejo Cancha ---")
                    print("6. Crear Complejo")
                    print("7. Crear Cancha")
                    print("--- Partido ---")
                    print("8. Programar Partido")
                    print("9. Sancionar Jugador")
                    print("10. Registrar Gol")
                    print("11. Registrar Planilla")
                    print("12. Registrar Tarjeta")
                    print("0. Volver")  # Opción para cerrar la aplicación

                    opcion = input("Seleccione una opción: ")
                    match opcion:
                        case "1":
                            if rol_usuario != 'administrador':
                                print("❌ ACCESO DENEGADO: Solo el administrador puede registrar el equipo.")
                            else:
                                id_equipo = int(input("ID Equipo: "))
                                nombre = input("Nombre del equipo: ")
                                id_torneo = int(input("ID Torneo: "))
                                id_facultad = int(input("ID Facultad: "))
                                ci_capitan = int(input("CI Capitán: "))
                                registrar_equipo(id_equipo,nombre,id_torneo,id_facultad,ci_capitan)
                        case "2":
                            if rol_usuario != 'administrador':
                                print("❌ ACCESO DENEGADO: Solo el administrador puede modificar el jugador.")
                            else:
                                ci = int(input("CI: "))
                                nombre = input("Nombre: ")
                                apellido = input("Apellido: ")
                                email = input("Email: ")
                                fecha_nacimiento = input("Fecha de nacimiento (YYYY-MM-DD): ")
                                id_facultad = int(input("ID Facultad: "))
                                tipo = input("Tipo (grado, posgrado, docente, funcionario): ")
                                registrar_jugador(ci,nombre,apellido,email,fecha_nacimiento,id_facultad,tipo)
                        case "3":
                            if rol_usuario != 'administrador':
                                print("❌ ACCESO DENEGADO: Solo el administrador puede fichar el jugador.")
                            else:
                                id_equipo = int(input("ID Equipo: "))
                                ci_jugador = int(input("CI Jugador: "))
                                id_torneo = int(input("ID Torneo: "))
                                numero_camiseta = int(input("Número de Camiseta: "))
                                print(aniadir_jugador(id_equipo,ci_jugador,id_torneo,numero_camiseta))
                        case "4":
                            if rol_usuario != 'administrador':
                                print("❌ ACCESO DENEGADO: Solo el administrador puede quitar al jugador del equipo.")
                            else:
                                id_equipo = int(input("ID Equipo: "))
                                ci_jugador = int(input("CI Jugador: "))
                                id_torneo = int(input("ID Torneo: "))
                                print(retirar_jugador(id_equipo,ci_jugador,id_torneo))
                        case "5":
                            if rol_usuario != 'administrador':
                                print("❌ ACCESO DENEGADO: Solo el administrador puede cambiar el capitan.")
                            else:
                                id_equipo = int(input("ID Equipo: "))
                                ci_jugador = int(input("CI Jugador: "))
                                id_torneo = int(input("ID Torneo: "))
                                print(cambiar_lider(id_equipo,ci_jugador,id_torneo))
                        case "6":
                            if rol_usuario != 'administrador':
                                print("❌ ACCESO DENEGADO: Solo el administrador puede registrar el complejo.")
                            else:
                                id_complejo = int(input("ID Complejo: "))
                                nombre_complejo = input("Nombre del complejo: ")
                                direccion = input("Direccion: ")
                                departamento = input("Departamento: ")
                                print(registrar_complejo(id_complejo,nombre_complejo,direccion,departamento))
                        case "7":
                            if rol_usuario != 'administrador':
                                print("❌ ACCESO DENEGADO: Solo el administrador puede registrar la cancha.")
                            else:
                                nombre_cancha = input("Nombre de la cancha: ")
                                id_complejo = int(input("ID del Complejo al que pertenece: "))
                                superficie = input("Superficie (sintético/parquet): ")
                                techada_input = input("¿Es techada? (si/no): ").lower()
                                techada = 1 if techada_input == "si" else 0
                                print(registrar_cancha(nombre_cancha, id_complejo, superficie, techada))

                        case "8":
                            if rol_usuario != 'administrador':
                                print("❌ ACCESO DENEGADO: Solo el administrador puede programar el partido.")
                            else:
                                id_partido = int(input("ID Partido: "))  # Pide y convierte a entero el ID del partido
                                id_torneo = int(input("ID Torneo: "))  # Pide y convierte a entero el ID del torneo
                                numero_fecha = int(input("Numero de fecha : "))  # Pide y convierte a entero el número de la fecha
                                id_equipo_local = int(input("ID Equipo Local: "))  # Pide y convierte a entero el ID del local
                                id_equipo_visitante = int(input("ID Equipo Visitante: "))  # Pide y convierte a entero el ID del visitante
                                dia = input("Día (YYYY-MM-DD): ")  # Pide el día del partido en texto
                                id_turno = int(input("ID Turno: "))  # Pide y convierte a entero el ID del turno
                                nombre_cancha = input("Nombre de cancha: ")  # Pide el nombre de la cancha
                                id_complejo = int(input("ID Complejo: "))  # Pide y convierte a entero el ID del complejo complejo
                                estado = input("Estado (programado/jugado/cancelado): ")  # Pide el estado inicial del partido
                                programar_partido(id_partido, id_torneo, numero_fecha, id_equipo_local, id_equipo_visitante, dia, id_turno, nombre_cancha, id_complejo,
                                estado)  # Llama al servicio que valida las reglas y registra el partido
                        case "9":
                            if rol_usuario != 'administrador':
                                print("❌ ACCESO DENEGADO: Solo el administrador puede sancionar al jugador.")
                            else:
                                id_sancion = int(input("ID Sanción: "))
                                ci_jugador = int(input("CI Jugador: "))
                                id_torneo = int(input("ID Torneo: "))
                                motivo = input("Motivo (roja/acumulación de amarillas/disciplinaria): ")
                                numero_fecha_inicio = int(input("Número de fecha de inicio: "))
                                cantidad_fechas = int(input("Cantidad de fechas de suspensión: "))

                                print(registrar_sancion(id_sancion, ci_jugador, id_torneo, motivo, numero_fecha_inicio,cantidad_fechas))
                        case "10":

                            id_gol = int(input("ID Gol: "))
                            id_partido = int(input("ID Partido: "))
                            ci_jugador = int(input("CI Jugador: "))
                            minuto = int(input("Minuto del gol: "))
                            autogol_input = input("¿Fue autogol? (si/no): ").lower()
                            autogol = 1 if autogol_input == "si" else 0
                            print(registrar_gol(usuario,contrasenia,id_gol, id_partido, ci_jugador, minuto, autogol))

                        case "11":
                            id_partido = int(input("ID Partido: "))
                            ci_jugador = int(input("CI Jugador: "))
                            id_equipo = int(input("ID Equipo: "))

                            print(registrar_en_planilla(usuario,contrasenia,id_partido, ci_jugador, id_equipo))

                        case "12":
                            id_tarjeta = int(input("ID Tarjeta: "))
                            id_partido = int(input("ID Partido: "))
                            ci_jugador = int(input("CI Jugador: "))
                            minuto = int(input("Minuto: "))
                            color = input("Color (amarilla/roja): ")
                            print(registrar_tarjeta(usuario,contrasenia,id_tarjeta, id_partido, ci_jugador, minuto, color))

                        case "0":
                                break

            case "2":
                while True:
                    print("\n--- Menú de Modificación ---")
                    print("--- Jugador / Equipo ---")
                    print("1. Modificar Jugador")
                    print("2. Modificar Nombre de Equipo")
                    print("--- Complejo / Cancha ---")
                    print("3. Modificar Complejo")
                    print("4. Modificar Cancha")
                    print("--- Partido / Sanciones ---")
                    print("5. Cambiar Estado de Partido")
                    print("6. Modificar Sanción de Jugador")
                    print("7. Modificar resultado de partido")
                    print("0. Volver")

                    opcion = input("Seleccione una opción: ")
                    match opcion:
                        case "1":
                            if rol_usuario != 'administrador':
                                print("❌ ACCESO DENEGADO: Solo el administrador puede modificar el jugador.")
                            else:
                                ci = int(input("CI del jugador a modificar: "))
                                nuevo_apellido = input("Nuevo Apellido: ")
                                nuevo_email = input("Nuevo Email: ")
                                nuevo_tipo = input("Nuevo Tipo (grado, posgrado, docente, funcionario): ")
                                print(modificar_jugador(ci, nuevo_apellido, nuevo_email, nuevo_tipo))

                        case "2":
                            if rol_usuario != 'administrador':
                                print("❌ ACCESO DENEGADO: Solo el administrador puede modificar el equipo.")
                            else:
                                id_equipo = int(input("ID del equipo a modificar: "))
                                nuevo_nombre = input("Nuevo nombre del equipo: ")
                                print(modificar_nombre_equipo(id_equipo, nuevo_nombre))

                        case "3":
                            if rol_usuario != 'administrador':
                                print("❌ ACCESO DENEGADO: Solo el administrador puede modificar el complejo.")
                            else:
                                id_complejo = int(input("ID del complejo a modificar: "))
                                nuevo_nombre = input("Nuevo nombre del complejo: ")
                                nueva_direccion = input("Nueva dirección: ")
                                nuevo_departamento = input("Nuevo departamento: ")
                                print(modificar_complejo(id_complejo, nuevo_nombre, nueva_direccion, nuevo_departamento))

                        case "4":
                            if rol_usuario != 'administrador':
                                print("❌ ACCESO DENEGADO: Solo el administrador puede modificar la cancha.")
                            else:
                                nombre_cancha = input("Nombre de la cancha a modificar: ")
                                id_complejo = int(input("ID del complejo al que pertenece: "))
                                nueva_superficie = input("Nueva superficie (sintético/parquet): ")
                                techada_input = input("¿Es techada? (si/no): ").lower()
                                nueva_techada = 1 if techada_input == "si" else 0
                                print(modificar_cancha(correo,contrasenia,nombre_cancha, id_complejo, nueva_superficie, nueva_techada))

                        case "5":
                            id_partido = int(input("ID del partido a modificar: "))
                            nuevo_estado = input("Nuevo Estado (programado/jugado/postergado/cancelado): ")
                            print(modificar_estado_partido(usuario,contrasenia,id_partido, nuevo_estado))

                        case "6":
                            if rol_usuario != 'administrador':
                                print("❌ ACCESO DENEGADO: Solo el administrador puede modificar la sancion.")
                            else:
                                id_sancion = int(input("ID de la sanción a modificar: "))
                                nuevo_motivo = input("Nuevo Motivo (roja/acumulación de amarillas/disciplinaria): ")
                                nueva_cantidad_fechas = int(input("Nueva cantidad de fechas de suspensión: "))
                                print(modificar_sancion(id_sancion, nuevo_motivo, nueva_cantidad_fechas))

                        case "7":
                            if rol_usuario != 'administrador':
                                print("❌ ACCESO DENEGADO: Solo el administrador puede modificar los resultados.")
                            else:
                                id_gol = int(input("ID del registro de gol a corregir: "))
                                nuevo_ci = int(input("Nueva CI del jugador que hizo el gol: "))
                                nuevo_minuto = int(input("Nuevo minuto del gol: "))
                                autogol_in = input("¿Fue autogol? (si/no): ").lower()
                                nuevo_autogol = 1 if autogol_in == "si" else 0
                                print(corregir_gol_partido(id_gol, nuevo_ci, nuevo_minuto, nuevo_autogol))

                        case "0":
                            break

            case "3":
                if rol_usuario != 'administrador':
                    print("❌ ACCESO DENEGADO: Solo el administrador puede borrar registros del sistema.")
                else:
                    while True:
                        print("\n--- Menú de Eliminación ---")
                        print("--- Jugador / Equipo ---")
                        print("1. Dar de Baja Jugador")
                        print("2. Eliminar Equipo")
                        print("--- Complejo / Cancha ---")
                        print("3. Eliminar Complejo")
                        print("4. Eliminar Cancha")
                        print("--- Partido / Sanciones ---")
                        print("5. Eliminar Partido")
                        print("6. Eliminar Sanción")
                        print("0. Volver")

                        opcion_baja = input("Seleccione una opción: ")
                        match opcion_baja:
                            case "1":
                                ci = int(input("CI del jugador a eliminar: "))
                                # Llamada a la función del servicio
                                print(eliminar_jugador(ci))

                            case "2":
                                id_equipo = int(input("ID del equipo a eliminar: "))
                                # Llamada a la función del servicio
                                print(eliminar_equipo(id_equipo))

                            case "3":
                                id_complejo = int(input("ID del complejo a eliminar: "))
                                # Llamada a la función del servicio
                                print(eliminar_complejo(id_complejo))

                            case "4":
                                nombre_cancha = input("Nombre de la cancha a eliminar: ")
                                id_complejo = int(input("ID del complejo al que pertenece: "))
                                # Llamada a la función del servicio
                                print(eliminar_cancha(nombre_cancha, id_complejo))

                            case "5":
                                id_partido = int(input("ID del partido a eliminar: "))
                                # Llamada a la función del servicio
                                print(eliminar_partido(id_partido))

                            case "6":
                                id_sancion = int(input("ID de la sanción a eliminar: "))
                                # Llamada a la función del servicio
                                print(eliminar_sancion(id_sancion))

                            case "0":
                                break

            case "4":
                while True:
                    print("\n--- MENÚ DE CONSULTAS Y REPORTES ---")
                    print("--- 🏆 Competencia Principal (Requieren ID de Torneo) ---")
                    print("1. Tabla de Posiciones")
                    print("2. Top 10 Goleadores por Torneo")
                    print("3. Tabla de Fair Play por Torneo")
                    print("--- ⚽ Goles y Estadísticas ---")
                    print("4. Promedio de Goles por Fecha")
                    print("5. Promedio de Goles Total del Torneo")
                    print("--- 🏢 Infraestructura y Horarios ---")
                    print("6. Canchas con Más Partidos")
                    print("7. Turnos con Más Partidos")
                    print("--- 🏃‍♂️ Jugadores y Facultades ---")
                    print("8. Cantidad de Jugadores por Facultad y Tipo")
                    print("9. Jugadores en Plantel que NO Jugaron en el Torneo")
                    print("--- ⚠️ Sanciones y Estados ---")
                    print("10. Cantidad de Sanciones por Equipo y Motivo")
                    print("11. Porcentaje de Partidos según Estado")
                    print("--- ➕ Reportes Adicionales ---")
                    print("12. Listar Todos los Partidos (Por ID)")
                    print("13. Ver Canchas de Césped Sintético")
                    print("14. Ver Todos los Partidos Jugados")
                    print("0. Volver al Menú Principal")

                    opcion = input("Seleccione un reporte para visualizar: ")
                    match opcion:
                        case "1":
                            id_torneo = int(input("Ingrese el ID del torneo para la Tabla de Posiciones: "))
                            posiciones = obtener_tabla_posiciones(
                                id_torneo)  # Llama al repositorio para obtener la lista de equipos y partidos jugados
                            print("\n--- TABLA DE POSICIONES ---")  # Título decorativo del reporte
                            for fila in posiciones:  # Recorre cada registro (tupla) devuelto por la base de datos
                                print(
                                    f"Equipo ID: {fila[0]} | Nombre: {fila[1]} | Partidos Jugados: {fila[2]}")  # Imprime los datos ordenados por columnas
                            input("Presione algo para continuar")
                        case "2":
                            id_torneo = int(input("Ingrese el ID del torneo para ver sus Goleadores: "))
                            goleadores = obtener_goleadores(
                                id_torneo)  # Llama al repositorio para obtener el top 10 de goleadores
                            print("\n--- TOP 10 GOLEADORES ---")
                            for g in goleadores:  # Recorre cada registro de la lista de goleadores
                                print(
                                    f"Cédula: {g[0]} | {g[1]} {g[2]} | Goles: {g[3]}")  # Imprime la cédula, nombre, apellido y cantidad total de goles
                            input("Presione algo para continuar")
                        case "3":
                            id_torneo = int(input("Ingrese el ID del torneo para calcular el Fair Play: "))
                            reporte_fp = obtener_tabla_fair_play(id_torneo)
                            print("\n--- TABLA DE FAIR PLAY ---")
                            for fila in reporte_fp:
                                print(
                                    f"Nombre: {fila['nombre']} | Amarillas: {fila['amarillas']} | Rojas: {fila['rojas']} | Puntaje Total: {fila['puntaje_total']}"
                                )
                            input("Presione algo para continuar")
                        case "4":
                            promedio_fecha = obtener_promedio_goles_por_fecha()
                            print("\n--- PROMEDIO DE GOLES POR FECHA ---")
                            for fila in promedio_fecha:
                                print(f"Número de Fecha: {fila[0]} | Promedio Goles: {float(fila[1]):.2f}")
                            input("Presione algo para continuar")

                        case "5":
                            promedio_total = obtener_promedio_goles_total()
                            print("\n--- PROMEDIO DE GOLES TOTAL DEL TORNEO ---")
                            if promedio_total and promedio_total[0] is not None:
                                print(f"Promedio General: {float(promedio_total[0]):.2f} goles por partido")
                            else:
                                print("No hay partidos registrados para calcular el promedio.")
                            input("Presione algo para continuar")

                        case "6":
                            canchas = obtener_canchas_mas_jugadas()
                            print("\n--- CANCHAS CON MÁS PARTIDOS JUGADOS ---")
                            for fila in canchas:
                                # fila[0]: id_complejo, fila[1]: nombre_cancha, fila[2]: cantidad
                                print(f"ID Complejo: {fila[0]} | Cancha: {fila[1]} | Partidos Jugados: {fila[2]}")
                            input("Presione algo para continuar")

                        case "7":
                            turnos = obtener_turnos_mas_jugados()
                            print("\n--- TURNOS CON MÁS PARTIDOS JUGADOS ---")
                            for fila in turnos:
                                # fila[0]: id_turno, fila[1]: hora_inicio, fila[2]: hora_fin, fila[3]: cantidad
                                print(
                                    f"ID Turno: {fila[0]} | Horario: {fila[1]} a {fila[2]} | Partidos Jugados: {fila[3]}")
                            input("Presione algo para continuar")

                        case "8":
                            jugadores_facu = obtener_jugadores_por_facultad_y_tipo()
                            print("\n--- CANTIDAD DE JUGADORES POR FACULTAD Y TIPO ---")
                            for fila in jugadores_facu:
                                # fila[0]: nombre facultad, fila[1]: tipo vinculación, fila[2]: cantidad
                                print(f"Facultad: {fila[0]} | Tipo: {fila[1]} | Cantidad: {fila[2]}")
                            input("Presione algo para continuar")

                        case "9":
                            id_torneo = int(input("Ingrese el ID del torneo para buscar jugadores sin minutos: "))
                            sin_planilla = obtener_jugadores_sin_planilla(id_torneo)
                            print("\n--- JUGADORES QUE NO FIGURAN EN NINGUNA PLANILLA ---")
                            for fila in sin_planilla:
                                # fila[0]: ci_jugador, fila[1]: id_equipo
                                print(f"Cédula Jugador: {fila[0]} | ID Equipo: {fila[1]}")
                            if not sin_planilla:
                                print("Todos los jugadores inscriptos tienen al menos un partido jugado.")
                            input("Presione algo para continuar")

                        case "10":
                            sanciones = obtener_sanciones_por_equipo_y_motivo()
                            print("\n--- CANTIDAD DE SANCIONES POR EQUIPO Y MOTIVO ---")
                            for fila in sanciones:
                                print(f"Equipo: {fila[0]} | Motivo: {fila[1]} | Cantidad: {fila[2]}")
                            input("Presione algo para continuar")

                        case "11":
                            porcentajes = obtener_porcentaje_partidos_estado()
                            print("\n--- PORCENTAJE DE PARTIDOS SEGÚN ESTADO ---")
                            for fila in porcentajes:
                                print(f"Estado: {fila[0]} | Porcentaje: {float(fila[1]):.2f}%")
                            input("Presione algo para continuar")

                        case "12":
                            partidos_id = obtener_todos_los_partidos_por_id()
                            print("\n--- TODOS LOS PARTIDOS (ORDENADOS POR ID) ---")
                            for fila in partidos_id:
                                print(
                                    f"ID Partido: {fila[0]} | Torneo: {fila[1]} | Fecha: {fila[2]} | Local: {fila[3]} | Visitante: {fila[4]} | Estado: {fila[5]}")
                            input("Presione algo para continuar")

                        case "13":
                            sinteticas = obtener_canchas_sinteticas()
                            print("\n--- CANCHAS DE CÉSPED SINTÉTICO ---")
                            for fila in sinteticas:
                                techada_text = "Sí" if fila[3] == 1 else "No"
                                print(
                                    f"ID Complejo: {fila[0]} | Cancha: {fila[1]} | Superficie: {fila[2]} | Techada: {techada_text}")
                            input("Presione algo para continuar")

                        case "14":
                            jugados = obtener_partidos_jugados()
                            print("\n--- PARTIDOS CON ESTADO 'JUGADO' ---")
                            for fila in jugados:
                                print(
                                    f"ID Partido: {fila[0]} | Torneo: {fila[1]} | Nro Fecha: {fila[2]} | Local: {fila[3]} | Visitante: {fila[4]}")
                            input("Presione algo para continuar")

                        case "0":
                            break


            case "0":  # Opción 0 (Salir)
                print("Saliendo del sistema...")
                break

            case _:  # Si el usuario ingresa un número u opción que no está contemplada
                print("Opción inválida. Intente nuevamente.")

main()
