from src.database.connection import get_connection
from datetime import datetime, timedelta

def obtener_todos_los_partidos():
    conexion = get_connection() # Llamo a la función de connection.py para abrir la conexión a MySQL
    cursor = conexion.cursor(dictionary=True) # dictionary=True devuelve los resultados como diccionarios (clave-valor)

    cursor.execute("SELECT * FROM partido;") # Ejecuto la consulta SQL como en MySQL
    partidos = cursor.fetchall() # Guardo los partidos en la variable partidos

    cursor.close() # Cierro el cursor para liberar memoria
    conexion.close() # Cierro la conexión para liberar memoria

    return partidos # Devuelvo los partidos


def registrar_partido(id_partido, id_torneo, numero_fecha, id_equipo_local, id_equipo_visitante, dia, id_turno, nombre_cancha, id_complejo, estado):
    conexion = get_connection() # Llamo a la función de connection.py para abrir la conexión a MySQL
    cursor = conexion.cursor() # El cursor ejecuta ordenes en la BD, sirve para operar en ella

    query = "INSERT INTO partido (id_partido, id_torneo, numero_fecha, id_equipo_local, id_equipo_visitante, dia, id_turno, nombre_cancha, id_complejo, estado) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s);"  # Inserto los datos
    valores = (id_partido, id_torneo, numero_fecha, id_equipo_local, id_equipo_visitante, dia, id_turno, nombre_cancha, id_complejo, estado) # Le paso los valores

    try:
        cursor.execute(query, valores)  # Ejecuta la consulta con los valores
        conexion.commit()  # Guarda los cambios, hay que hacerlo luego de un INSERT, UPDATE o DELETE
        filas_afectadas = cursor.rowcount  # Nos dice cuantas filas se afectaron (1 si salió bien)
        conexion.close()
        return filas_afectadas > 0 # Devuelve true si se guardó la fila (1 a la vez se insertan) y false si no
    except Exception as e:
        conexion.rollback() # En caso de fallo vuelvo al estado anterior
        cursor.close()
        conexion.close()
        return f"NO SE PUDO REGISTRAR El PARTIDO: {e}"

def modificar_estado_partido(usuario,contrasenia,id_partido, nuevo_estado):
    conexion = get_connection(usuario,contrasenia)
    cursor = conexion.cursor(dictionary=True)

    try:
        # 1. Actualizamos el estado del partido
        query = "UPDATE partido SET estado = %s WHERE id_partido = %s"
        valores = (nuevo_estado, id_partido)
        cursor.execute(query, valores)

        # Si el partido se jugó, procesamos los goles y las tarjetas para las sanciones automáticas
        if nuevo_estado == 'jugado':

            # 2. Obtener los IDs de los equipos del partido y la fecha actual
            query = "SELECT id_equipo_local, id_equipo_visitante, id_torneo, numero_fecha FROM partido WHERE id_partido = %s"
            valores = (id_partido,)
            cursor.execute(query, valores)
            partido = cursor.fetchone()

            if partido:
                id_local = partido['id_equipo_local']
                id_visitante = partido['id_equipo_visitante']
                id_torneo = partido['id_torneo']
                num_fecha = partido['numero_fecha']

                # 3. Contar goles del local (goles a favor del local + autogoles del visitante)
                query = """
                        SELECT COUNT(*) as total \
                        FROM gol
                        WHERE id_partido = %s \
                          AND ((id_equipo = %s AND autogol = 0) OR (id_equipo = %s AND autogol = 1)) \
                        """
                valores = (id_partido, id_local, id_visitante)
                cursor.execute(query, valores)
                goles_local = cursor.fetchone()['total']

                # 4. Contar goles del visitante (goles a favor del visitante + autogoles del local)
                valores = (id_partido, id_visitante, id_local)
                cursor.execute(query, valores)
                goles_visitante = cursor.fetchone()['total']

                # Aquí la base de datos ya tiene los goles listos para que el reporte calcule los puntos (3, 1 o 0)

                # 5. Sanciones automáticas por Tarjeta Roja en este partido
                query = "SELECT ci_jugador FROM tarjeta WHERE id_partido = %s AND color = 'roja'"
                valores = (id_partido,)
                cursor.execute(query, valores)
                rojas = cursor.fetchall()

                for jugador in rojas:
                    query = """
                            INSERT INTO sancion_jugador (ci_jugador, id_torneo, motivo, numero_fecha_inicio, cantidad_fechas)
                            VALUES (%s, %s, 'roja', %s, 1) \
                            """
                    valores = (jugador['ci_jugador'], id_torneo, num_fecha + 1)
                    cursor.execute(query, valores)

                # 6. Sanciones automáticas por acumulación de 3 Tarjetas Amarillas en el torneo
                # Buscamos jugadores del partido que hayan recibido amarilla hoy
                query = "SELECT DISTINCT ci_jugador FROM tarjeta WHERE id_partido = %s AND color = 'amarilla'"
                valores = (id_partido,)
                cursor.execute(query, valores)
                amarillas_hoy = cursor.fetchall()

                for jugador in amarillas_hoy:
                    # Contamos cuántas amarillas totales acumula en toda la edición del torneo
                    query = """
                            SELECT COUNT(*) as total \
                            FROM tarjeta t \
                                     INNER JOIN partido p ON t.id_partido = p.id_partido
                            WHERE t.ci_jugador = %s \
                              AND p.id_torneo = %s \
                              AND t.color = 'amarilla' \
                            """
                    valores = (jugador['ci_jugador'], id_torneo)
                    cursor.execute(query, valores)
                    total_amarillas = cursor.fetchone()['total']

                    # Si acumuló exactamente 3 (o múltiplos de 3), se le aplica la sanción automática
                    if total_amarillas % 3 == 0:
                        query = """
                                INSERT INTO sancion_jugador (ci_jugador, id_torneo, motivo, numero_fecha_inicio, cantidad_fechas)
                                VALUES (%s, %s, 'acumulación de amarillas', %s, 1) \
                                """
                        valores = (jugador['ci_jugador'], id_torneo, num_fecha + 1)
                        cursor.execute(query, valores)

        conexion.commit()  # Guardamos todo el paquete junto de forma segura
        cursor.close()
        conexion.close()
        return f"ESTADO ACTUALIZADO A '{nuevo_estado}' Y SANCIONES PROCESADAS"

    except Exception as e:
        conexion.rollback()  # Si algo falla en las sanciones, no se cambia el estado del partido
        cursor.close()
        conexion.close()
        return f"NO SE PUDO MODIFICAR EL ESTADO DEL PARTIDO: {e}"

def corregir_gol_partido(id_gol, nuevo_ci_jugador, nuevo_minuto, nuevo_autogol):
    conexion = get_connection()
    cursor = conexion.cursor(dictionary=True)

    try:
        # 1. Averiguar a qué partido pertenece el gol y qué día se disputó
        query = """
            SELECT p.id_partido, p.dia 
            FROM gol g
            INNER JOIN partido p ON g.id_partido = p.id_partido
            WHERE g.id_gol = %s
        """
        valores = (id_gol,)
        cursor.execute(query, valores)
        partido = cursor.fetchone()

        if not partido:
            cursor.close()
            conexion.close()
            return "EL REGISTRO DE GOL ESPECIFICADO NO EXISTE"

        # 2. VALIDACIÓN DE LAS 48 HORAS: Controlar el tiempo desde la disputa (Pág. 2)
        fecha_partido = partido['dia']
        fecha_hoy = datetime.now().date()

        if fecha_hoy - fecha_partido > timedelta(days=2):
            cursor.close()
            conexion.close()
            return "NO SE PUEDE CORREGIR: Ya pasaron las 48 horas posteriores a la disputa del partido."

        # 3. Si está dentro del plazo, modificamos los datos del gol de forma segura
        query = "UPDATE gol SET ci_jugador = %s, minuto = %s, autogol = %s WHERE id_gol = %s"
        valores = (nuevo_ci_jugador, nuevo_minuto, nuevo_autogol, id_gol)
        cursor.execute(query, valores)

        conexion.commit()  # Confirma la modificación del gol en MySQL
        cursor.close()
        conexion.close()
        return "REGISTRO DE GOL CORREGIDO (EL RESULTADO SE RECALCULARÁ EN LA TABLA)"

    except Exception as e:
        conexion.rollback()
        cursor.close()
        conexion.close()
        return f"NO SE PUDO CORREGIR EL GOL: {e}"


def eliminar_partido(id_partido):
    conexion = get_connection()
    cursor = conexion.cursor(dictionary=True)

    # 1. Consultar el estado actual del partido antes de borrar
    query = "SELECT estado FROM partido WHERE id_partido = %s"
    valores = (id_partido,)
    cursor.execute(query, valores)
    partido = cursor.fetchone()

    # Si el partido no existe, cerramos y avisamos
    if not partido:
        cursor.close()
        conexion.close()
        return "EL PARTIDO ESPECIFICADO NO EXISTE"

    # RESTRICCIÓN DE LA UCU: Bloquear la eliminación si ya fue jugado
    if partido['estado'] == 'jugado':
        cursor.close()
        conexion.close()
        return "UN PARTIDO JUGADO NO PUEDE ELIMINARSE"

    # 2. Si no está jugado, procedemos a borrarlo
    query = "DELETE FROM partido WHERE id_partido = %s"
    valores = (id_partido,)

    try:
        cursor.execute(query, valores)
        conexion.commit()  # OBLIGATORIO: Confirma y aplica el borrado en MySQL
        cursor.close()
        conexion.close()
        return "PARTIDO ELIMINADO CORRECTAMENTE"
    except Exception as e:
        conexion.rollback()  # Cancela la operación ante cualquier fallo de integridad
        cursor.close()
        conexion.close()
        return f"NO SE PUDO ELIMINAR EL PARTIDO: {e}"


def registrar_gol(usuario,contrasenia,id_gol, id_partido, ci_jugador, minuto, autogol):

    conexion = get_connection(usuario,contrasenia)
    cursor = conexion.cursor(dictionary=True)

    query = "SELECT COUNT(*) as total FROM planilla_partido WHERE id_partido = %s AND ci_jugador = %s"
    valores = (id_partido, ci_jugador)
    cursor.execute(query, valores)
    resultado = cursor.fetchone()

    if resultado and resultado['total'] > 0:
        query = "INSERT INTO gol (id_gol, id_partido, ci_jugador, minuto, autogol) VALUES (%s, %s, %s, %s, %s)"
        valores = (id_gol, id_partido, ci_jugador, minuto, autogol)

        try:
            cursor.execute(query, valores)
            conexion.commit()
            cursor.close()
            conexion.close()
            return "GOL REGISTRADO CON ÉXITO"
        except Exception as e:
            conexion.rollback()
            cursor.close()
            conexion.close()
            return f"ERRROR AL INSERTAR EL GOL: {e}"
    else:
        cursor.close()
        conexion.close()
        return "El jugador no se encuentra en la planilla del partido"

def registrar_en_planilla(usuario,contrasenia,id_partido, ci_jugador, id_equipo):
    conexion = get_connection(usuario,contrasenia)
    cursor = conexion.cursor(dictionary=True)

    query = "SELECT id_equipo_local, id_equipo_visitante FROM partido WHERE id_partido = %s"
    valores = (id_partido,)
    cursor.execute(query, valores)
    partido = cursor.fetchone()

    if not partido:
        cursor.close()
        conexion.close()
        return "El partido no existe"

    if id_equipo not in [partido['id_equipo_local'], partido['id_equipo_visitante']]:
        cursor.close()
        conexion.close()
        return "El equipo no pertenece al partido"


    query = "SELECT COUNT(*) as total FROM equipo_jugador_torneo WHERE id_equipo = %s AND ci_jugador = %s"
    valores = (id_equipo, ci_jugador)
    cursor.execute(query, valores)
    plantel = cursor.fetchone()

    if not plantel or plantel['total'] == 0:
        cursor.close()
        conexion.close()
        return "El jugador no pertenece al plantel de ese equipo"


    query = "INSERT INTO planilla_partido (id_partido, ci_jugador, id_equipo) VALUES (%s, %s, %s)"
    valores = (id_partido, ci_jugador, id_equipo)

    try:
        cursor.execute(query, valores)
        conexion.commit()
        cursor.close()
        conexion.close()
        return "JUGADOR REGISTRADO EN LA PLANILLA CORRECTAMENTE"
    except Exception as e:
        conexion.rollback()
        cursor.close()
        conexion.close()
        return f"NO SE PUDO REGISTRAR EN LA PLANILLA: {e}"


def registrar_tarjeta(usuario,contrasenia,id_tarjeta, id_partido, ci_jugador, minuto, color):
    conexion = get_connection(usuario,contrasenia)
    cursor = conexion.cursor(dictionary=True)


    query = "SELECT COUNT(*) as total FROM planilla_partido WHERE id_partido = %s AND ci_jugador = %s"
    valores = (id_partido, ci_jugador)
    cursor.execute(query, valores)
    resultado = cursor.fetchone()

    if resultado and resultado['total'] > 0:

        query = "INSERT INTO tarjeta (id_tarjeta, id_partido, ci_jugador, minuto, color) VALUES (%s, %s, %s, %s, %s)"
        valores = (id_tarjeta, id_partido, ci_jugador, minuto, color)

        try:
            cursor.execute(query, valores)
            conexion.commit()
            cursor.close()
            conexion.close()
            return "TARJETA REGISTRADA CON ÉXITO"
        except Exception as e:
            conexion.rollback()
            cursor.close()
            conexion.close()
            return f"ERROR AL REGISTRAR TARJETA: {e}"
    else:
        cursor.close()
        conexion.close()
        return "El jugador no se encuentra en la planilla del partido"


def registrar_sancion(id_sancion, ci_jugador, id_torneo, motivo, numero_fecha_inicio, cantidad_fechas):
    conexion = get_connection()
    cursor = conexion.cursor(dictionary=True)

    # Usamos tus variables fijas 'query' y 'valores' protegidas con %s
    query = """
        INSERT INTO sancion_jugador (id_sancion, ci_jugador, id_torneo, motivo, numero_fecha_inicio, cantidad_fechas) 
        VALUES (%s, %s, %s, %s, %s, %s)
    """
    valores = (id_sancion, ci_jugador, id_torneo, motivo, numero_fecha_inicio, cantidad_fechas)

    try:
        cursor.execute(query, valores)
        cursor.close()
        conexion.close()
        return "SANCIÓN REGISTRADA CORRECTAMENTE"
    except Exception as e:
        cursor.close()
        conexion.close()
        return f"NO SE PUDO REGISTRAR LA SANCIÓN: {e}"

def modificar_sancion(id_sancion, nuevo_motivo, nueva_cantidad_fechas):
    conexion = get_connection()
    cursor = conexion.cursor(dictionary=True)

    # Usamos tus variables fijas protegidas con %s para actualizar la sanción
    query = """
        UPDATE sancion_jugador 
        SET motivo = %s, cantidad_fechas = %s 
        WHERE id_sancion = %s
    """
    valores = (nuevo_motivo, nueva_cantidad_fechas, id_sancion)

    try:
        cursor.execute(query, valores)
        conexion.commit()  # OBLIGATORIO: Guarda los cambios en MySQL
        cursor.close()
        conexion.close()
        return "SANCIÓN MODIFICADA CORRECTAMENTE"
    except Exception as e:
        conexion.rollback()  # Cancela la transacción si ocurre un error
        cursor.close()
        conexion.close()
        return f"NO SE PUDO MODIFICAR LA SANCIÓN: {e}"

def eliminar_sancion(id_sancion):
    conexion = get_connection()
    cursor = conexion.cursor(dictionary=True)

    # Usamos tus variables fijas protegidas con %s
    query = "DELETE FROM sancion_jugador WHERE id_sancion = %s"
    valores = (id_sancion,)

    try:
        cursor.execute(query, valores)
        conexion.commit()  # OBLIGATORIO: Confirma y aplica el borrado en MySQL
        cursor.close()
        conexion.close()
        return "SANCIÓN ELIMINADA CORRECTAMENTE"
    except Exception as e:
        conexion.rollback()  # Cancela la operación ante cualquier error imprevisto
        cursor.close()
        conexion.close()
        return f"NO SE PUDO ELIMINAR LA SANCIÓN: {e}"
