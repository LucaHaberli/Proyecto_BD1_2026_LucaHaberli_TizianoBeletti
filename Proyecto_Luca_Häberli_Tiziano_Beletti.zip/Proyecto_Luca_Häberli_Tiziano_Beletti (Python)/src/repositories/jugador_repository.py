from src.database.connection import get_connection

def obtener_todos_los_jugadores():
    conexion = get_connection() # Llamo a la función de connection.py para abrir la conexión a MySQL
    cursor = conexion.cursor(dictionary=True) # dictionary=True devuelve los resultados como diccionarios (clave-valor)

    cursor.execute("SELECT * FROM jugador;") # Ejecuto la consulta SQL como en MySQL
    jugadores = cursor.fetchall() # Guardo los jugadores en la variable jugadores

    cursor.close() # Cierro el cursor para liberar memoria
    conexion.close() # Cierro la conexión para liberar memoria

    return jugadores # Devuelvo los jugadores

def registrar_jugador(ci, nombre, apellido, email, fecha_nacimiento, id_facultad, tipo):
    conexion = get_connection() # Llamo a la función de connection.py para abrir la conexión a MySQL
    cursor = conexion.cursor() # El cursor ejecuta ordenes en la BD, sirve para operar en ella

    query = "INSERT INTO jugador (ci, nombre, apellido, email, fecha_nacimiento, id_facultad, tipo) VALUES (%s, %s, %s, %s, %s, %s, %s);"  # Inserto los datos
    valores = (ci, nombre, apellido, email, fecha_nacimiento, id_facultad, tipo) # Le paso los valores

    cursor.execute(query, valores) # Ejecuta la consulta con los valores
    conexion.commit() # Guarda los cambios, hay que hacerlo luego de un INSERT, UPDATE o DELETE

    filas_afectadas = cursor.rowcount # Nos dice cuantas filas se afectaron (1 si salió bien)

    cursor.close() # Cierro el cursor para liberar memoria
    conexion.close() # Cierro la conexión para liberar memoria

    return filas_afectadas > 0 # Devuelve true si se guardó la fila (1 a la vez se insertan) y false si no

def modificar_jugador(ci, nuevo_apellido, nuevo_email, nuevo_tipo):
    conexion = get_connection()
    cursor = conexion.cursor(dictionary=True)


    query = "UPDATE jugador SET apellido = %s, email = %s, tipo = %s WHERE ci = %s"
    valores = (nuevo_apellido, nuevo_email, nuevo_tipo, ci)

    try:
        cursor.execute(query, valores)
        conexion.commit()
        cursor.close()
        conexion.close()
        return "JUGADOR MODIFICADO CORRECTAMENTE"
    except Exception as e:
        conexion.rollback()
        cursor.close()
        conexion.close()
        return f"NO SE PUDO MODIFICAR EL JUGADOR: {e}"

def eliminar_jugador(ci):
    conexion = get_connection()
    cursor = conexion.cursor(dictionary=True)

    # Usamos tus variables fijas protegidas con %s
    query = "DELETE FROM jugador WHERE ci = %s"
    valores = (ci,)

    try:
        cursor.execute(query, valores)
        conexion.commit()  # OBLIGATORIO: Confirma y aplica el borrado en MySQL
        cursor.close()
        conexion.close()
        return "JUGADOR ELIMINADO CORRECTAMENTE"
    except Exception as e:
        conexion.rollback()  # Cancela la operación si el jugador está referenciado en otra tabla
        cursor.close()
        conexion.close()
        return f"NO SE PUDO ELIMINAR EL JUGADOR: {e}"

