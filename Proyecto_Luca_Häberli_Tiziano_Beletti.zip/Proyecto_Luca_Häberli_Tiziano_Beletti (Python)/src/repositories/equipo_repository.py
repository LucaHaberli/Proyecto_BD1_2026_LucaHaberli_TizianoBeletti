from src.database.connection import get_connection


def obtener_todos_los_equipos():
    conexion = get_connection()  # Llamo a la función de connection.py para abrir la conexión a MySQL
    cursor = conexion.cursor(dictionary=True)  # dictionary=True devuelve los resultados como diccionarios (clave-valor)

    cursor.execute("SELECT * FROM equipo;")  # Ejecuto la consulta SQL como en MySQL
    equipos = cursor.fetchall()  # Guardo los equipos en la variable equipos

    cursor.close()  # Cierro el cursor para liberar memoria
    conexion.close()  # Cierro la conexión para liberar memoria

    return equipos  # Devuelvo los equipos


def registrar_equipo(id_equipo, nombre, id_torneo, id_facultad, ci_capitan):
    conexion = get_connection()  # Llamo a la función de connection.py para abrir la conexión a MySQL
    cursor = conexion.cursor()  # El cursor ejecuta ordenes en la BD, sirve para operar en ella

    query = "INSERT INTO equipo (id_equipo, nombre, id_torneo, id_facultad, ci_capitan) VALUES (%s, %s, %s, %s, %s);"  # Inserto los datos
    valores = (id_equipo, nombre, id_torneo, id_facultad, ci_capitan)  # Le paso los valores

    cursor.execute(query, valores)  # Ejecuta la consulta con los valores
    conexion.commit()  # Guarda los cambios, hay que hacerlo luego de un INSERT, UPDATE o DELETE

    filas_afectadas = cursor.rowcount  # Nos dice cuantas filas se afectaron (1 si salió bien)

    cursor.close()  # Cierro el cursor para liberar memoria
    conexion.close()  # Cierro la conexión para liberar memoria

    return filas_afectadas > 0  # Devuelve true si se guardó la fila (1 a la vez se insertan) y false si no

def eliminar_equipo(id_equipo):
    conexion = get_connection()
    cursor = conexion.cursor(dictionary=True)

    # Usamos tus variables fijas protegidas con %s
    query = "DELETE FROM equipo WHERE id_equipo = %s"
    valores = (id_equipo,)

    try:
        cursor.execute(query, valores)
        conexion.commit()  # OBLIGATORIO: Confirma y aplica el borrado en MySQL
        cursor.close()
        conexion.close()
        return "EQUIPO ELIMINADO CORRECTAMENTE"
    except Exception as e:
        conexion.rollback()  # Si el equipo está asignado a un partido o planilla, cancela para evitar errores
        cursor.close()
        conexion.close()
        return f"NO SE PUDO ELIMINAR EL EQUIPO: {e}"


def modificar_nombre_equipo(id_equipo, nuevo_nombre):
    conexion = get_connection()
    cursor = conexion.cursor(dictionary=True)

    # Usamos tus variables fijas protegidas con %s
    query = "UPDATE equipo SET nombre = %s WHERE id_equipo = %s"
    valores = (nuevo_nombre, id_equipo)

    try:
        cursor.execute(query, valores)
        conexion.commit()  # OBLIGATORIO: Confirma y guarda el cambio de nombre en MySQL
        cursor.close()
        conexion.close()
        return "NOMBRE DE EQUIPO ACTUALIZADO"
    except Exception as e:
        conexion.rollback()  # Deshace cualquier cambio temporal en caso de error
        cursor.close()
        conexion.close()
        return f"NO SE PUDO MODIFICAR EL EQUIPO: {e}"

def fichar_jugador(id_equipo, ci_jugador, id_torneo, numero_camiseta):
    conexion = get_connection()  # Llamo a la función de connection.py para abrir la conexión a MySQL
    cursor = conexion.cursor(dictionary=True)  # dictionary=True devuelve los resultados como diccionarios (clave-valor)
    query = f"INSERT INTO equipo_jugador_torneo (id_equipo, ci_jugador, id_torneo, numero_camiseta) values (%s,%s,%s,%s)"
    valores = (id_equipo, ci_jugador, id_torneo, numero_camiseta)
    try:
        cursor.execute(query, valores)
        conexion.commit()
        cursor.close()
        conexion.close()
        return "JUGADOR FICHADO CORRECTAMENTE"
    except Exception as e:
        conexion.rollback
        cursor.close()
        conexion.close()
        return f"NO SE PUDO FICHAR AL JUGADOR: {e}"

def quitar_jugador(id_equipo, ci_jugador, id_torneo):
    conexion = get_connection()  # Llamo a la función de connection.py para abrir la conexión a MySQL
    cursor = conexion.cursor(dictionary=True)  # dictionary=True devuelve los resultados como diccionarios (clave-valor)
    query = "DELETE FROM equipo_jugador_torneo WHERE id_equipo = %s AND ci_jugador = %s AND id_torneo = %s"
    valores = (id_equipo, ci_jugador, id_torneo)
    try:
        cursor.execute(query, valores)
        conexion.commit()
        cursor.close()
        conexion.close()
        return "JUGADOR QUITADO CORRECTAMENTE"
    except Exception as e:
        conexion.rollback
        cursor.close()
        conexion.close()
        return f"NO SE PUDO QUITAR AL JUGADOR DEL EQUIPO: {e}"

def cambiar_capitan(id_equipo, ci_jugador):
    conexion = get_connection()
    cursor = conexion.cursor(dictionary=True)
    query = "UPDATE equipo SET ci_capitan = %s WHERE id_equipo = %s"
    valores = (ci_jugador, id_equipo)
    cursor.execute(query, valores)
    cursor.close()
    conexion.close()

def registrar_complejo(id_complejo, nombre, direccion, departamento):
    conexion = get_connection()
    cursor = conexion.cursor(dictionary=True)

    # Usamos tus variables estándar 'query' y 'valores' con %s
    query = "INSERT INTO complejo (id_complejo, nombre, direccion, departamento) VALUES (%s, %s, %s, %s)"
    valores = (id_complejo, nombre, direccion, departamento)

    try:
        cursor.execute(query, valores)
        cursor.close()
        conexion.close()
        return "COMPLEJO REGISTRADO CORRECTAMENTE"
    except Exception as e:
        cursor.close()
        conexion.close()
        return f"NO SE PUDO REGISTRAR EL COMPLEJO: {e}"

def modificar_complejo(id_complejo, nuevo_nombre, nueva_direccion, nuevo_departamento):
    conexion = get_connection()
    cursor = conexion.cursor(dictionary=True)

    # Usamos tus variables fijas protegidas con %s
    query = "UPDATE complejo SET nombre = %s, dirección = %s, departamento = %s WHERE id_complejo = %s"
    valores = (nuevo_nombre, nueva_direccion, nuevo_departamento, id_complejo)

    try:
        cursor.execute(query, valores)
        conexion.commit()  # OBLIGATORIO: Guarda los cambios en MySQL
        cursor.close()
        conexion.close()
        return "COMPLEJO MODIFICADO CORRECTAMENTE"
    except Exception as e:
        conexion.rollback()  # Si algo falla, cancelamos la transacción
        cursor.close()
        conexion.close()
        return f"NO SE PUDO MODIFICAR EL COMPLEJO: {e}"

def eliminar_complejo(id_complejo):
    conexion = get_connection()
    cursor = conexion.cursor(dictionary=True)

    # Usamos tus variables fijas protegidas con %s
    query = "DELETE FROM complejo WHERE id_complejo = %s"
    valores = (id_complejo,)

    try:
        cursor.execute(query, valores)
        conexion.commit()  # OBLIGATORIO: Confirma y aplica el borrado en MySQL
        cursor.close()
        conexion.close()
        return "COMPLEJO ELIMINADO CORRECTAMENTE"
    except Exception as e:
        conexion.rollback()  # Cancela la operación si el complejo tiene canchas asociadas
        cursor.close()
        conexion.close()
        return f"NO SE PUDO ELIMINAR EL COMPLEJO: {e}"


def registrar_cancha(nombre_cancha, id_complejo, superficie, techada):
    conexion = get_connection()
    cursor = conexion.cursor(dictionary=True)

    # Usamos tus variables fijas 'query' y 'valores' seguras
    query = "INSERT INTO cancha (nombre_cancha, id_complejo, superficie, techada) VALUES (%s, %s, %s, %s)"
    valores = (nombre_cancha, id_complejo, superficie, techada)

    try:
        cursor.execute(query, valores)
        conexion.commit()  # Confirma los cambios en MySQL
        cursor.close()
        conexion.close()
        return "CANCHA CREADA CORRECTAMENTE"
    except Exception as e:
        conexion.rollback()
        cursor.close()
        conexion.close()
        return f"NO SE PUDO CREAR LA CANCHA: {e}"

def modificar_cancha(nombre_cancha, id_complejo, nueva_superficie, nueva_techada):
    conexion = get_connection()
    cursor = conexion.cursor(dictionary=True)

    # El WHERE usa la clave compuesta (nombre_cancha e id_complejo) para no pisar canchas de otros complejos
    query = """
        UPDATE cancha 
        SET superficie = %s, techada = %s 
        WHERE nombre_cancha = %s AND id_complejo = %s
    """
    valores = (nueva_superficie, nueva_techada, nombre_cancha, id_complejo)

    try:
        cursor.execute(query, valores)
        conexion.commit()  # OBLIGATORIO: Guarda los cambios en MySQL
        cursor.close()
        conexion.close()
        return "CANCHA MODIFICADA CORRECTAMENTE"
    except Exception as e:
        conexion.rollback()  # Cancela la transacción en caso de error
        cursor.close()
        conexion.close()
        return f"NO SE PUDO MODIFICAR LA CANCHA: {e}"

def eliminar_cancha(nombre_cancha, id_complejo):
    conexion = get_connection()
    cursor = conexion.cursor(dictionary=True)

    # El WHERE usa la clave compuesta (nombre_cancha e id_complejo) de forma segura
    query = "DELETE FROM cancha WHERE nombre_cancha = %s AND id_complejo = %s"
    valores = (nombre_cancha, id_complejo)

    try:
        cursor.execute(query, valores)
        conexion.commit()  # OBLIGATORIO: Confirma y aplica el borrado en MySQL
        cursor.close()
        conexion.close()
        return "CANCHA ELIMINADA CORRECTAMENTE"
    except Exception as e:
        conexion.rollback()  # Cancela el borrado si la cancha está asignada a un partido
        cursor.close()
        conexion.close()
        return f"NO SE PUDO ELIMINAR LA CANCHA: {e}"

