from src.database.connection import get_connection

def obtener_tabla_posiciones(id_torneo): # Recibe id_torneo para calcular la tabla de posiciones
    conexion = get_connection() # Llamo a la función de connection.py para abrir la conexión a MySQL
    cursor = conexion.cursor() # El cursor sirve para operar en la BD

    query = f"""
             SELECT equipo.id_equipo, equipo.nombre, COUNT(partido.id_partido) 
             FROM equipo 
             LEFT JOIN partido ON (equipo.id_equipo = partido.id_equipo_local OR equipo.id_equipo = partido.id_equipo_visitante) 
             WHERE equipo.id_torneo = %s 
             GROUP BY equipo.id_equipo, equipo.nombre 
             """ # Devuelve los equipos con sus partidos jugados
    valores = (id_torneo,)
    cursor.execute(query,valores) # Ejecuto la consulta
    posiciones = cursor.fetchall() # Guarda el resultado en una lista

    cursor.close() # Cierro el cursor para liberar memoria
    conexion.close() # Cierro la conexión para liberar memoria

    return posiciones # Devuelvo las posiciones

def obtener_goleadores(id_torneo): # Recibe id_torneo para buscar los goleadores
    conexion = get_connection()  # Llamo a la función de connection.py para abrir la conexión a MySQL
    cursor = conexion.cursor()  # El cursor sirve para operar en la BD
    valores = (id_torneo,)
    query = f"""
             SELECT jugador.ci, jugador.nombre, jugador.apellido, COUNT(gol.id_gol) 
             FROM jugador 
             JOIN gol ON jugador.ci = gol.ci_jugador 
             JOIN partido ON gol.id_partido = partido.id_partido 
             WHERE gol.autogol = false AND partido.id_torneo = %s 
             GROUP BY jugador.ci, jugador.nombre, jugador.apellido 
             ORDER BY COUNT(gol.id_gol) DESC 
             LIMIT 10 """ # Devuelve los 10 jugadores que hicieron más goles

    cursor.execute(query,valores) # Ejecuto la consulta
    goleadores = cursor.fetchall() # Guarda los resultados en una lista

    cursor.close() # Cierro el cursor para liberar memoria
    conexion.close() # Cierro la conexión para liberar memoria

    return goleadores # Devuelvo los goleadores

def obtener_canchas_mas_jugadas():
    conexion = get_connection()
    cursor = conexion.cursor()  # Cursor estándar para tuplas indexadas

    query = """
        SELECT cancha.id_complejo, cancha.nombre_cancha, COUNT(partido.id_partido)
        FROM cancha
        JOIN partido ON cancha.nombre_cancha = partido.nombre_cancha AND cancha.id_complejo = partido.id_complejo
        GROUP BY cancha.id_complejo, cancha.nombre_cancha
        ORDER BY COUNT(partido.id_partido) DESC;
    """

    try:
        cursor.execute(query)
        resultados = cursor.fetchall()
        cursor.close()
        conexion.close()
        return resultados
    except Exception as e:
        cursor.close()
        conexion.close()
        raise RuntimeError(f"Error al obtener canchas más jugadas: {e}")

def obtener_promedio_goles_por_fecha():
    conexion = get_connection()
    cursor = conexion.cursor()  # Cursor estándar para tuplas indexadas

    query = """
        SELECT partido.numero_fecha, COUNT(gol.id_gol) / COUNT(DISTINCT partido.id_partido)
        FROM partido
        LEFT JOIN gol ON partido.id_partido = gol.id_partido
        GROUP BY partido.numero_fecha
        ORDER BY partido.numero_fecha ASC;
    """

    try:
        cursor.execute(query)
        resultados = cursor.fetchall()
        cursor.close()
        conexion.close()
        return resultados
    except Exception as e:
        cursor.close()
        conexion.close()
        raise RuntimeError(f"Error al obtener promedio por fecha: {e}")

def obtener_promedio_goles_total():
    conexion = get_connection()
    cursor = conexion.cursor()  # Cursor estándar

    query = """
        SELECT COUNT(gol.id_gol) / COUNT(partido.id_partido)
        FROM partido
        LEFT JOIN gol ON partido.id_partido = gol.id_partido;
    """

    try:
        cursor.execute(query)
        resultado = cursor.fetchone()  # Es una única fila con un único valor
        cursor.close()
        conexion.close()
        return resultado
    except Exception as e:
        cursor.close()
        conexion.close()
        raise RuntimeError(f"Error al obtener promedio total: {e}")

def obtener_tabla_fair_play(id_torneo):
    conexion = get_connection()
    cursor = conexion.cursor(dictionary=True)

    query = """
        SELECT equipo.nombre, 
               SUM(tarjeta.color = 'amarilla') AS amarillas, 
               SUM(tarjeta.color = 'roja') AS rojas, 
               (SUM(tarjeta.color = 'amarilla') + SUM(tarjeta.color = 'roja') * 3) AS puntaje_total
        FROM equipo
        LEFT JOIN planilla_partido ON equipo.id_equipo = planilla_partido.id_equipo
        LEFT JOIN tarjeta ON planilla_partido.id_partido = tarjeta.id_partido
        LEFT JOIN partido ON planilla_partido.id_partido = partido.id_partido
        WHERE partido.id_torneo = %s
        GROUP BY equipo.nombre
        ORDER BY puntaje_total ASC;
    """
    valores = (id_torneo,)

    try:
        cursor.execute(query, valores)
        resultados = cursor.fetchall()
        cursor.close()
        conexion.close()

        # Limpiamos los None de la consulta para entregar un diccionario limpio
        for fila in resultados:
            fila['amarillas'] = int(fila['amarillas']) if fila['amarillas'] is not None else 0
            fila['rojas'] = int(fila['rojas']) if fila['rojas'] is not None else 0
            fila['puntaje_total'] = int(fila['puntaje_total']) if fila['puntaje_total'] is not None else 0

        return resultados  # Retorna el array de diccionarios puro
    except Exception as e:
        cursor.close()
        conexion.close()
        raise RuntimeError(f"Error en el repositorio al obtener fair play: {e}")

def obtener_turnos_mas_jugados():
    conexion = get_connection()
    cursor = conexion.cursor()  # Cursor estándar para tuplas indexadas

    query = """
        SELECT turno.id_turno, turno.hora_inicio, turno.hora_fin, COUNT(partido.id_partido)
        FROM turno
        JOIN partido ON turno.id_turno = partido.id_turno
        GROUP BY turno.id_turno, turno.hora_inicio, turno.hora_fin
        ORDER BY COUNT(partido.id_partido) DESC;
    """

    try:
        cursor.execute(query)
        resultados = cursor.fetchall()
        cursor.close()
        conexion.close()
        return resultados
    except Exception as e:
        cursor.close()
        conexion.close()
        raise RuntimeError(f"Error al obtener turnos más jugados: {e}")

def obtener_jugadores_por_facultad_y_tipo():
    conexion = get_connection()
    cursor = conexion.cursor()  # Cursor estándar para tuplas indexadas

    query = """
        SELECT facultad.nombre, jugador.tipo, COUNT(jugador.ci)
        FROM facultad
        JOIN jugador ON facultad.id_facultad = jugador.id_facultad
        GROUP BY facultad.nombre, jugador.tipo
        ORDER BY COUNT(jugador.ci) DESC;
    """

    try:
        cursor.execute(query)
        resultados = cursor.fetchall()
        cursor.close()
        conexion.close()
        return resultados
    except Exception as e:
        cursor.close()
        conexion.close()
        raise RuntimeError(f"Error al obtener cantidad de jugadores por facultad: {e}")

def obtener_jugadores_sin_planilla(id_torneo):
    conexion = get_connection()
    cursor = conexion.cursor()  # Cursor estándar para tuplas indexadas

    query = """
        SELECT equipo_jugador_torneo.ci_jugador, equipo_jugador_torneo.id_equipo
        FROM equipo_jugador_torneo
        LEFT JOIN planilla_partido ON equipo_jugador_torneo.ci_jugador = planilla_partido.ci_jugador 
                                  AND equipo_jugador_torneo.id_torneo = (SELECT id_torneo FROM partido WHERE partido.id_partido = planilla_partido.id_partido LIMIT 1)
        WHERE equipo_jugador_torneo.id_torneo = %s AND planilla_partido.ci_jugador IS NULL;
    """
    valores = (id_torneo,)

    try:
        cursor.execute(query, valores)
        resultados = cursor.fetchall()
        cursor.close()
        conexion.close()
        return resultados
    except Exception as e:
        cursor.close()
        conexion.close()
        raise RuntimeError(f"Error al obtener jugadores sin minutos: {e}")

def obtener_sanciones_por_equipo_y_motivo():
    conexion = get_connection()
    cursor = conexion.cursor()

    query = """
        SELECT equipo.nombre, s.motivo, COUNT(s.id_sancion)
        FROM equipo
        JOIN equipo_jugador_torneo ejt ON equipo.id_equipo = ejt.id_equipo
        JOIN sancion_jugador s ON ejt.ci_jugador = s.ci_jugador AND ejt.id_torneo = s.id_torneo
        GROUP BY equipo.nombre, s.motivo
        ORDER BY COUNT(s.id_sancion) DESC;
    """

    try:
        cursor.execute(query)
        resultados = cursor.fetchall()
        cursor.close()
        conexion.close()
        return resultados
    except Exception as e:
        cursor.close()
        conexion.close()
        raise RuntimeError(f"Error al obtener sanciones por equipo: {e}")

def obtener_porcentaje_partidos_estado():
    conexion = get_connection()
    cursor = conexion.cursor()

    query = """
        SELECT partido.estado, COUNT(partido.id_partido) * 100.0 / (SELECT COUNT(*) FROM partido)
        FROM partido
        GROUP BY partido.estado;
    """

    try:
        cursor.execute(query)
        resultados = cursor.fetchall()
        cursor.close()
        conexion.close()
        return resultados
    except Exception as e:
        cursor.close()
        conexion.close()
        raise RuntimeError(f"Error al obtener porcentaje de partidos: {e}")

def obtener_todos_los_partidos_por_id():
    conexion = get_connection()
    cursor = conexion.cursor()
    query = "SELECT id_partido, id_torneo, numero_fecha, id_equipo_local, id_equipo_visitante, estado FROM partido ORDER BY id_partido ASC;"
    cursor.execute(query)
    res = cursor.fetchall()
    cursor.close()
    conexion.close()
    return res

def obtener_canchas_sinteticas():
    conexion = get_connection()
    cursor = conexion.cursor()
    query = "SELECT id_complejo, nombre_cancha, superficie, techada FROM cancha WHERE superficie = 'sintético';"
    cursor.execute(query)
    res = cursor.fetchall()
    cursor.close()
    conexion.close()
    return res

def obtener_partidos_jugados():
    conexion = get_connection()
    cursor = conexion.cursor()
    query = "SELECT id_partido, id_torneo, numero_fecha, id_equipo_local, id_equipo_visitante FROM partido WHERE estado = 'jugado';"
    cursor.execute(query)
    res = cursor.fetchall()
    cursor.close()
    conexion.close()
    return res
