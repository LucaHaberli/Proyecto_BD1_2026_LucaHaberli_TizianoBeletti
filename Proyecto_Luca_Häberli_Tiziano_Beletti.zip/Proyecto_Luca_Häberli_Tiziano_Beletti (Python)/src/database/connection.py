import mysql.connector

def get_connection(user='admin_torneo', password='PasswordAdmin123*'):  # Se conecta a la BD torneo_ucu. Por defecto se conecta con los datos del admin, pero se le puede pasar el usuario y contraseña del planillero.
    connection = mysql.connector.connect(host='localhost', database='torneo_ucu', user=user, password=password)
    if (connection.is_connected() == True):
        return connection

def iniciar_sesion(correo, contrasenia):
    conexion = get_connection()
    cursor = conexion.cursor(dictionary=True)


    query = "SELECT rol FROM login WHERE correo = %s AND contraseña = %s"
    valores = (correo, contrasenia)
    cursor.execute(query, valores)
    usuario = cursor.fetchone()

    cursor.close()
    conexion.close()

    if usuario:
        return usuario['rol']
    return None
