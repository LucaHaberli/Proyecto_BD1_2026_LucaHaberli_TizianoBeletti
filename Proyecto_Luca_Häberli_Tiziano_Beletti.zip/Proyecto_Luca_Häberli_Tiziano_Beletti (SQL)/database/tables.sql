CREATE DATABASE torneo_ucu;
USE torneo_ucu;

CREATE TABLE login (
    correo VARCHAR(100) PRIMARY KEY,
    contraseña VARCHAR(100),
    rol VARCHAR(100)
);

CREATE TABLE facultad (
    id_facultad INT PRIMARY KEY,
    nombre VARCHAR(100)
);

CREATE TABLE jugador (
    ci INT PRIMARY KEY,
    nombre VARCHAR(100),
    apellido VARCHAR(100),
    email VARCHAR(100),
    fecha_nacimiento DATE,
    id_facultad INT,
    tipo VARCHAR(100),
    FOREIGN KEY (id_facultad) REFERENCES facultad(id_facultad)
);

CREATE TABLE torneo (
    id_torneo INT PRIMARY KEY,
    nombre VARCHAR(100),
    anio INT,
    semestre INT,
    fecha_inicio DATE,
    fecha_fin DATE,
    estado VARCHAR(100)
);

CREATE TABLE equipo (
    id_equipo INT PRIMARY KEY,
    nombre VARCHAR(100),
    id_torneo INT,
    id_facultad INT,
    ci_capitan INT,
    FOREIGN KEY (id_torneo) REFERENCES torneo(id_torneo),
    FOREIGN KEY (id_facultad) REFERENCES facultad(id_facultad),
    FOREIGN KEY (ci_capitan) REFERENCES jugador(ci)
);

CREATE TABLE equipo_jugador_torneo (
    id_equipo INT,
    ci_jugador INT,
    id_torneo INT,
    numero_camiseta INT,
    PRIMARY KEY (id_equipo, ci_jugador, id_torneo),
    FOREIGN KEY (id_equipo) REFERENCES equipo(id_equipo),
    FOREIGN KEY (ci_jugador) REFERENCES jugador(ci),
    FOREIGN KEY (id_torneo) REFERENCES torneo(id_torneo)
);

CREATE TABLE complejo (
    id_complejo INT PRIMARY KEY,
    nombre VARCHAR(100),
    direccion VARCHAR(100),
    departamento VARCHAR(100)
);

CREATE TABLE cancha (
    nombre_cancha VARCHAR(100),
    id_complejo INT,
    superficie VARCHAR(100),
    techada BOOLEAN,
    PRIMARY KEY (nombre_cancha, id_complejo),
    FOREIGN KEY (id_complejo) REFERENCES complejo(id_complejo)
);

CREATE TABLE turno (
    id_turno INT PRIMARY KEY,
    hora_inicio TIME,
    hora_fin TIME
);

CREATE TABLE partido (
    id_partido INT,
    id_torneo INT,
    numero_fecha INT,
    id_equipo_local INT,
    id_equipo_visitante INT,
    dia DATE,
    id_turno INT,
    nombre_cancha VARCHAR(100),
    id_complejo INT,
    estado VARCHAR(100),
    PRIMARY KEY (id_partido, id_torneo),
    FOREIGN KEY (id_torneo) REFERENCES torneo(id_torneo),
    FOREIGN KEY (id_equipo_local) REFERENCES equipo(id_equipo),
    FOREIGN KEY (id_equipo_visitante) REFERENCES equipo(id_equipo),
    FOREIGN KEY (id_turno) REFERENCES turno(id_turno),
    FOREIGN KEY (nombre_cancha, id_complejo) REFERENCES cancha(nombre_cancha, id_complejo) -- En cancha está definida así la PK
);

CREATE TABLE planilla_partido (
    id_partido INT,
    ci_jugador INT,
    id_equipo INT,
    PRIMARY KEY (id_partido, ci_jugador),
    FOREIGN KEY (ci_jugador) REFERENCES jugador(ci),
    FOREIGN KEY (id_equipo) REFERENCES equipo(id_equipo)
);

CREATE TABLE gol (
    id_gol INT PRIMARY KEY,
    id_partido INT,
    ci_jugador INT,
    minuto INT,
    autogol BOOLEAN,
    FOREIGN KEY (ci_jugador) REFERENCES jugador(ci)
);

CREATE TABLE tarjeta (
    id_tarjeta INT PRIMARY KEY,
    id_partido INT,
    ci_jugador INT,
    minuto INT,
    color VARCHAR(100),
    FOREIGN KEY (ci_jugador) REFERENCES jugador(ci)

);

CREATE TABLE sancion_jugador (
    id_sancion INT PRIMARY KEY,
    ci_jugador INT,
    id_torneo INT,
    motivo VARCHAR(100),
    numero_fecha_inicio INT,
    cantidad_fechas INT,
    FOREIGN KEY (ci_jugador) REFERENCES jugador(ci),
    FOREIGN KEY (id_torneo) REFERENCES torneo(id_torneo)
);

CREATE USER 'admin_torneo'@'localhost' IDENTIFIED BY 'PasswordAdmin123*'; -- Crea un usuario llamado admin_torneo que se va a conectar desde mi PC ('localhost') con la contraseña PasswordAdmin123*
GRANT ALL PRIVILEGES ON torneo_ucu.* TO 'admin_torneo'@'localhost'; -- Le da todos los permisos al admin_torneo recién creado: crear equipos, cambiar fechas, etc

CREATE USER 'planillero_torneo'@'localhost' IDENTIFIED BY 'PasswordPlanillero123*'; -- Crea otro usuario diferente llamado planillero_torneo con su propia contraseña.
GRANT SELECT ON torneo_ucu.* TO 'planillero_torneo'@'localhost'; -- A este usuario se le da permiso para ver todo (SELECT), pero solo puede insertar y modificar (INSERT y UPDATE) en tres tablas: planilla_partido, gol y tarjeta. Ya que un planillero no debe poder borrar un equipo, cambiar las tablas de posisciones ni crear torneos
GRANT INSERT, UPDATE ON torneo_ucu.planilla_partido TO 'planillero_torneo'@'localhost';
GRANT INSERT, UPDATE ON torneo_ucu.gol TO 'planillero_torneo'@'localhost';
GRANT INSERT, UPDATE ON torneo_ucu.tarjeta TO 'planillero_torneo'@'localhost';

FLUSH PRIVILEGES; -- Le avisa a MySQL que ya se terminaron de configurar los permisos y recarga la tabla de usuarios para que empiece a regir ahora mismo