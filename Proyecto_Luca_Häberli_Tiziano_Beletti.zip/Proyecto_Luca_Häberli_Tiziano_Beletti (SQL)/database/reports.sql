USE torneo_ucu;
-- Reporte 1: Tabla de posisciones (partidos jugados)
SELECT equipo.nombre, COUNT(partido.id_partido)
FROM equipo
JOIN partido ON equipo.id_equipo = partido.id_equipo_local OR equipo.id_equipo = partido.id_equipo_visitante
WHERE partido.id_torneo = 1 AND partido.estado = 'jugado'
GROUP BY equipo.nombre;

-- Reporte 2: Tabla de goleadores (10 jugadores con mas goles)
SELECT jugador.ci, jugador.nombre, jugador.apellido, COUNT(gol.id_gol)
FROM jugador
JOIN gol ON jugador.ci = gol.ci_jugador
GROUP BY jugador.ci, jugador.nombre, jugador.apellido
ORDER BY COUNT(gol.id_gol) DESC
LIMIT 10;

-- Reporte 3: Tabla de fair play (1 punto por cada tarjeta amarilla y 3 por cada roja)
SELECT equipo.nombre, SUM(tarjeta.color = 'amarilla'), SUM(tarjeta.color = 'roja'), ( SUM(tarjeta.color = 'amarilla') + SUM(tarjeta.color = 'roja') * 3 )
FROM equipo
LEFT JOIN planilla_partido ON equipo.id_equipo = planilla_partido.id_equipo
LEFT JOIN tarjeta ON planilla_partido.id_partido = tarjeta.id_partido
GROUP BY equipo.nombre
ORDER BY ( SUM(tarjeta.color = 'amarilla') + SUM(tarjeta.color = 'roja') * 3 ) ASC;

-- Reporte 4.1: Promedio de goles por partido en cada fecha
SELECT partido.numero_fecha, COUNT(gol.id_gol) / COUNT(partido.id_partido)
FROM partido
LEFT JOIN gol ON partido.id_partido = gol.id_partido
GROUP BY partido.numero_fecha
ORDER BY COUNT(gol.id_gol) / COUNT(partido.id_partido) ASC;

-- Reporte 4.2: Promedio de goles por partido en todo el torneo (no por fecha)
SELECT COUNT(gol.id_gol) / COUNT(partido.id_partido)
FROM partido
LEFT JOIN gol ON partido.id_partido = gol.id_partido;

-- Reporte 5.1: Canchas con más partidos jugados
SELECT cancha.id_complejo, cancha.nombre_cancha, COUNT(partido.id_partido)
FROM cancha
JOIN partido ON cancha.nombre_cancha = partido.nombre_cancha
GROUP BY cancha.id_complejo, cancha.nombre_cancha
ORDER BY COUNT(partido.id_partido) DESC;

-- Reporte 5.2: Turnos con más partidos jugados
SELECT turno.id_turno, turno.hora_inicio, turno.hora_fin, COUNT(partido.id_partido)
FROM turno
JOIN partido ON turno.id_turno = partido.id_turno
GROUP BY turno.id_turno, turno.hora_inicio, turno.hora_fin
ORDER BY COUNT(partido.id_partido) DESC;

-- Reporte 6: Cantidad de jugadores por facultad y por tipo
SELECT facultad.nombre, jugador.tipo, COUNT(jugador.ci)
FROM facultad
JOIN jugador ON facultad.id_facultad = jugador.id_facultad
GROUP BY facultad.nombre, jugador.tipo
ORDER BY COUNT(jugador.ci) DESC;

-- Reporte 7: Jugadores inscriptos en un plantel que no están en la planilla de juego
SELECT equipo_jugador_torneo.ci_jugador, equipo_jugador_torneo.id_equipo
FROM equipo_jugador_torneo
LEFT JOIN planilla_partido ON equipo_jugador_torneo.ci_jugador = planilla_partido.ci_jugador
WHERE planilla_partido.ci_jugador IS NULL; -- Queremos los que no están en la planilla

-- Reporte 8: Cantidad de sanciones por equipo y por motivo
SELECT equipo.nombre, sancion_jugador.motivo, COUNT(sancion_jugador.id_sancion)
FROM equipo
JOIN equipo_jugador_torneo ON equipo.id_equipo = equipo_jugador_torneo.id_equipo
JOIN sancion_jugador ON equipo_jugador_torneo.ci_jugador = sancion_jugador.ci_jugador
GROUP BY equipo.nombre, sancion_jugador.motivo
ORDER BY COUNT(sancion_jugador.id_sancion) DESC;

-- Reporte 9: Porcentaje de partidos jugados
SELECT partido.estado, COUNT(partido.id_partido) * 100.0 / (SELECT COUNT(partido.id_partido) FROM partido)
FROM partido
GROUP BY partido.estado;

-- Reporte adicional 1: Listar todos los partidos ordenados por sus IDs
SELECT *
FROM partido
ORDER BY partido.id_partido ASC;

-- Reporte adicional 2: Ver todas las canchas con superficie "sintético"
SELECT *
FROM cancha
WHERE cancha.superficie = 'sintético';

-- Reporte adicional 3: Ver todos los partidos con estado "jugado"
SELECT *
FROM partido
WHERE partido.estado = 'jugado';

SELECT * FROM partido;