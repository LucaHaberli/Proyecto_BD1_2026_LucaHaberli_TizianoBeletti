USE torneo_ucu;
-- 1. Login: Login tiene TABne usuarios admin y planilleros
INSERT INTO login (correo, contraseña, rol) VALUES
('admin@ucu.edu.uy', 'Admin123', 'administrador'),
('planillero@ucu.edu.uy', 'Planillero123*', 'planillero');

-- 2. Facultad
INSERT INTO facultad VALUES
(1, 'Facultad de Ingeniería y Tecnologías'),
(2, 'Facultad de Ciencias Empresariales'),
(3, 'Facultad de Derecho'),
(4, 'Facultad de Psicología');

-- 3. Jugadores: Facultad de Ingeniería y Tecnologías (Facultad 1)
INSERT INTO jugador (ci, nombre, apellido, email, fecha_nacimiento, id_facultad, tipo) VALUES
-- Equipo 1: Ingeniería FC
(50100001, 'Luca', 'Häberli', 'luca.haberli@ucu.edu.uy', '2006-01-06', 1, 'grado'),
(50100002, 'Martín', 'Giménez', 'martin.gimenez@ucu.edu.uy', '2006-07-08', 1, 'grado'),
(50100003, 'Gonzalo', 'Malo', 'gonzalo.malo@ucu.edu.uy', '2006-12-15', 1, 'grado'),
(50100004, 'Joaquín', 'Caballero', 'joaquin.caballero@ucu.edu.uy', '2005-07-15', 1, 'grado'),
(50100005, 'Marcelo', 'Rodríguez', 'marcelo.rodriguez@ucu.edu.uy', '1990-01-01', 1, 'docente'),

-- Equipo 2: Bit Power
(50100006, 'Ignacio', 'Gómez', 'ignacio.gomez@ucu.edu.uy', '2003-01-22', 1, 'grado'),
(50100007, 'Valentin', 'Suárez', 'valentin.suarez@ucu.edu.uy', '2004-09-14', 1, 'grado'),
(50100008, 'Nicolas', 'Castro', 'nicolas.castro@ucu.edu.uy', '2003-06-05', 1, 'grado'),
(50100009, 'Ramiro', 'Ramos', 'ramiro.ramos@ucu.edu.uy', '2004-12-19', 1, 'grado'),
(50100010, 'Enrique', 'Baltazar', 'enrique.baltazar@ucu.edu.uy', '1995-06-09', 1, 'docente'),

-- 3. Jugadores: Facultad de Ingeniería y Tecnologías (Facultad 2)
-- Equipo 3: Business Players
(50200011, 'Santiago', 'Benitez', 'santiago.benitez@ucu.edu.uy', '2003-03-11', 2, 'grado'),
(50200012, 'Agustín', 'Martínez', 'agustin.martinez@ucu.edu.uy', '2004-05-25', 2, 'grado'),
(50200013, 'Federico', 'López', 'federico.lopez@ucu.edu.uy', '2003-09-08', 2, 'grado'),
(50200014, 'Tomás', 'Fernandez', 'tomas.fernandez@ucu.edu.uy', '2004-01-17', 2, 'grado'),
(50200015, 'Facundo', 'Giménez', 'facundo.gimenez@ucu.edu.uy', '2002-10-29', 2, 'grado'),

-- Equipo 4: Finanzas United
(50200016, 'Rodrigo', 'Acosta', 'rodrigo.acosta@ucu.edu.uy', '2004-02-03', 2, 'grado'),
(50200017, 'Manuel', 'Sosa', 'manuel.sosa@ucu.edu.uy', '2003-07-12', 2, 'grado'),
(50200018, 'Alejandro', 'Perez', 'alejandro.perez@ucu.edu.uy', '2004-08-19', 2, 'grado'),
(50200019, 'Diego', 'Viera', 'diego.viera@ucu.edu.uy', '2003-11-23', 2, 'grado'),
(50200020, 'Esteban', 'Ruiz', 'esteban.ruiz@ucu.edu.uy', '2004-04-06', 2, 'grado'),

-- 3. Jugadores: Facultad de Derecho (Facultad 3)
-- Equipo 5: Derecho FC
(50300021, 'Camila', 'Silva', 'camila.silva@ucu.edu.uy', '2003-06-15', 3, 'grado'),
(50300022, 'Sofia', 'Rodriguez', 'sofia.rodriguez@ucu.edu.uy', '2004-09-02', 3, 'grado'),
(50300023, 'Valentina', 'Gomez', 'valentina.gomez@ucu.edu.uy', '2003-12-11', 3, 'grado'),
(50300024, 'Martina', 'Fernandez', 'martina.fernandez@ucu.edu.uy', '2004-02-28', 3, 'grado'),
(50300025, 'Lucia', 'Perez', 'lucia.perez@ucu.edu.uy', '2002-05-19', 3, 'grado'),

-- 3. Jugadores: Facultad de Psicología (Facultad 4)
-- Equipo 6: Psico Gol
(50400026, 'Clara', 'Mendez', 'clara.mendez@ucu.edu.uy', '2004-03-21', 4, 'grado'),
(50400027, 'Paula', 'Rossi', 'paula.rossi@ucu.edu.uy', '2003-09-13', 4, 'grado'),
(50400028, 'Mariana', 'Blanco', 'mariana.blanco@ucu.edu.uy', '2004-11-05', 4, 'grado'),
(50400029, 'Josefina', 'Gallo', 'josefina.gallo@ucu.edu.uy', '2003-02-25', 4, 'grado'),
(50400030, 'Antonella', 'Pittamiglio', 'antonella.pitta@ucu.edu.uy', '2002-12-08', 4, 'grado');


-- 4. Torneo
INSERT INTO torneo (id_torneo, nombre, anio, semestre, fecha_inicio, fecha_fin, estado) VALUES
(1, 'Torneo Interfacultades 2026', 2026, 2, '2026-08-04', '2026-11-27', 'en curso');

-- 5. Equipos
INSERT INTO equipo (id_equipo, nombre, id_torneo, id_facultad, ci_capitan) VALUES
(1, 'Ingeniería FC', 1, 1, 50100001),
(2, 'Bit Power', 1, 1, 50100006),
(3, 'Business Players', 1, 2, 50200011),
(4, 'Finanzas United', 1, 2, 50200016),
(5, 'Derecho FC', 1, 3, 50300021),
(6, 'Psico Gol', 1, 4, 50400026);


-- 6. Equipo_jugador_torneo (Planteles de 5 jugadores por equipo)
INSERT INTO equipo_jugador_torneo (id_equipo, ci_jugador, id_torneo, numero_camiseta) VALUES
-- Equipo 1: Ingeniería FC
(1, 50100001, 1, 10),
(1, 50100002, 1, 5),
(1, 50100003, 1, 4),
(1, 50100004, 1, 8),
(1, 50100005, 1, 9),

-- Equipo 2: Bit Power
(2, 50100006, 1, 1),
(2, 50100007, 1, 2),
(2, 50100008, 1, 3),
(2, 50100009, 1, 11),
(2, 50100010, 1, 7),

-- Equipo 3: Business Players
(3, 50200011, 1, 10),
(3, 50200012, 1, 7),
(3, 50200013, 1, 5),
(3, 50200014, 1, 4),
(3, 50200015, 1, 9),

-- Equipo 4: Finanzas United
(4, 50200016, 1, 1),
(4, 50200017, 1, 6),
(4, 50200018, 1, 8),
(4, 50200019, 1, 10),
(4, 50200020, 1, 9),

-- Equipo 5: Derecho FC
(5, 50300021, 1, 10),
(5, 50300022, 1, 2),
(5, 50300023, 1, 3),
(5, 50300024, 1, 4),
(5, 50300025, 1, 5),

-- Equipo 6: Psico Gol
(6, 50400026, 1, 9),
(6, 50400027, 1, 10),
(6, 50400028, 1, 6),
(6, 50400029, 1, 7),
(6, 50400030, 1, 8);


-- 7. Complejo
INSERT INTO complejo (id_complejo, nombre, direccion, departamento) VALUES
(1, 'Complejo Deportivo UCU', 'Av. 8 de Octubre 2738', 'Montevideo');

-- 8. Cancha
INSERT INTO cancha (nombre_cancha, id_complejo, superficie, techada) VALUES
('Cancha 1', 1, 'sintético', true),
('Cancha 2', 1, 'sintético', false);

-- 9. Turno (Son turnos de una hora)
INSERT INTO turno (id_turno, hora_inicio, hora_fin) VALUES
(1, '18:00:00', '19:00:00'),
(2, '19:00:00', '20:00:00'),
(3, '20:00:00', '21:00:00');

-- 10. Partido
INSERT INTO partido (id_partido, id_torneo, numero_fecha, id_equipo_local, id_equipo_visitante, dia, id_turno, nombre_cancha, id_complejo, estado) VALUES
-- Fecha 1
(1, 1, 1, 1, 3, '2026-08-05', 1, 'Cancha 1', 1, 'jugado'),
(2, 1, 1, 2, 4, '2026-08-05', 2, 'Cancha 1', 1, 'jugado'),
(3, 1, 1, 6, 5, '2026-08-05', 3, 'Cancha 1', 1, 'jugado'),

-- Fecha 2
(4, 1, 2, 1, 2, '2026-08-12', 1, 'Cancha 1', 1, 'jugado'),
(5, 1, 2, 6, 3, '2026-08-12', 2, 'Cancha 1', 1, 'jugado'),
(6, 1, 2, 4, 5, '2026-08-12', 3, 'Cancha 1', 1, 'jugado'),

-- Fecha 3
(7, 1, 3, 6, 1, '2026-08-19', 1, 'Cancha 1', 1, 'jugado'),
(8, 1, 3, 4, 3, '2026-08-19', 2, 'Cancha 1', 1, 'jugado'),
(9, 1, 3, 5, 2, '2026-08-19', 3, 'Cancha 1', 1, 'jugado');


-- 11. Planilla_partido (plantel de cada equipo)
INSERT INTO planilla_partido (id_partido, ci_jugador, id_equipo) VALUES
-- Fecha 1
-- Partido 1: Ingeniería FC (1) vs Business Players (3)
(1, 50100001, 1),
(1, 50100002, 1),
(1, 50100003, 1),
(1, 50100004, 1),
(1, 50100005, 1),
(1, 50200011, 3),
(1, 50200012, 3),
(1, 50200013, 3),
(1, 50200014, 3),
(1, 50200015, 3),

-- Partido 2: Bit Power (2) vs Finanzas United (4)
(2, 50100006, 2),
(2, 50100007, 2),
(2, 50100008, 2),
(2, 50100009, 2),
(2, 50100010, 2),
(2, 50200016, 4),
(2, 50200017, 4),
(2, 50200018, 4),
(2, 50200019, 4),
(2, 50200020, 4),

-- Partido 3: Psico Gol (6) vs Derecho FC (5)
(3, 50400026, 6),
(3, 50400027, 6),
(3, 50400028, 6),
(3, 50400029, 6),
(3, 50400030, 6),
(3, 50300021, 5),
(3, 50300022, 5),
(3, 50300023, 5),
(3, 50300024, 5),
(3, 50300025, 5),

-- Fecha 2
-- Partido 4: Ingeniería FC (1) vs Bit Power (2)
(4, 50100001, 1),
(4, 50100002, 1),
(4, 50100003, 1),
(4, 50100004, 1),
(4, 50100005, 1),
(4, 50100006, 2),
(4, 50100007, 2),
(4, 50100008, 2),
(4, 50100009, 2),
(4, 50100010, 2),

-- Partido 5: Psico Gol (6) vs Business Players (3)
(5, 50400026, 6),
(5, 50400027, 6),
(5, 50400028, 6),
(5, 50400029, 6),
(5, 50400030, 6),
(5, 50200011, 3),
(5, 50200012, 3),
(5, 50200013, 3),
(5, 50200014, 3),
(5, 50200015, 3),

-- Partido 6: Finanzas United (4) vs Derecho FC (5)
(6, 50200016, 4),
(6, 50200017, 4),
(6, 50200018, 4),
(6, 50200019, 4),
(6, 50200020, 4),
(6, 50300021, 5),
(6, 50300022, 5),
(6, 50300023, 5),
(6, 50300024, 5),
(6, 50300025, 5),

-- Fecha 3
-- Partido 7: Psico Gol (6) vs Ingeniería FC (1)
(7, 50400026, 6),
(7, 50400027, 6),
(7, 50400028, 6),
(7, 50400029, 6),
(7, 50400030, 6),
(7, 50100001, 1),
(7, 50100002, 1),
(7, 50100003, 1),
(7, 50100004, 1),
(7, 50100005, 1),

-- Partido 8: Finanzas United (4) vs Business Players (3)
(8, 50200016, 4),
(8, 50200017, 4),
(8, 50200018, 4),
(8, 50200019, 4),
(8, 50200020, 4),
(8, 50200011, 3),
(8, 50200012, 3),
(8, 50200013, 3),
(8, 50200014, 3),
(8, 50200015, 3),

-- Partido 9: Derecho FC (5) vs Bit Power (2)
(9, 50300021, 5),
(9, 50300022, 5),
(9, 50300023, 5),
(9, 50300024, 5),
(9, 50300025, 5),
(9, 50100006, 2),
(9, 50100007, 2),
(9, 50100008, 2),
(9, 50100009, 2),
(9, 50100010, 2);


-- 12. Gol
INSERT INTO gol (id_gol, id_partido, ci_jugador, minuto, autogol) VALUES
-- Partido 1 (Ingeniería FC vs Business Players)
(1, 1, 50100001, 12, false), -- Gol de Luca Häberli (Ingeniería FC)
(2, 1, 50100001, 35, false), -- Gol de Luca Häberli (Ingeniería FC)
(3, 1, 50200011, 40, false), -- Gol de Santiago Benitez (Business Players)

-- Partido 4 (Ingeniería FC vs Bit Power)
(4, 4, 50100002, 15, false), -- Gol de Martín Giménez (Ingeniería FC)
(5, 4, 50100001, 33, false); -- Gol de Luca Häberli (Ingeniería FC)


-- 13. Tarjeta
INSERT INTO tarjeta (id_tarjeta, id_partido, ci_jugador, minuto, color) VALUES
(1, 1, 50100003, 30, 'amarilla'), -- Tarjeta amarilla a Gonzalo Malo (Ingeniería FC) en el Partido 1
(2, 4, 50100005, 42, 'roja');  -- Tarjeta roja a Marcelo Rodríguez (Ingeniería FC) en el Partido 4


-- 14. Sanción
INSERT INTO sancion_jugador (id_sancion, ci_jugador, id_torneo, motivo, numero_fecha_inicio, cantidad_fechas) VALUES
(1, 50100005, 1, 'roja', 3, 1);  -- Sanción a Marcelo Rodríguez por la tarjeta roja recibida, cumpliendo 1 fecha de suspensión a partir de la Fecha 3